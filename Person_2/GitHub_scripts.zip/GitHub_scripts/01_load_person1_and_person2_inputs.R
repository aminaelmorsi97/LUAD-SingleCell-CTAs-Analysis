###############################################################################
# 01_load_person1_and_person2_inputs.R
#
# Purpose:
#   Start the Person 2 CNV workflow from the project inputs prepared by
#   Person 1. The script creates one clean metadata table with stable cell_id,
#   Sample, Patient_ID, Cell_subtype, and doublet information.
#
# Key principle:
#   Patient identity comes from the validated Sample -> Patient mapping.
#   We do not invent Patient_ID from cell barcodes.
###############################################################################


project_root <- Sys.getenv("CTA_PROJECT_ROOT", unset = "D:/CTA")
person1_dir <- file.path(project_root, "person 1")
person2_dir <- file.path(project_root, "person 2")

metadata_file <- file.path(person1_dir, "GSE131907_metadata_curated.csv")
mapping_file <- file.path(person1_dir, "GSE131907_sample_to_patient_mapping.csv")
malignant_file <- file.path(person2_dir, "GSE131907_malignant_with_patient_id.rds")

for (f in c(metadata_file, mapping_file, malignant_file)) {
  if (!file.exists(f)) stop("Required input is missing: ", f)
}

mapping <- read.csv(mapping_file, stringsAsFactors = FALSE, check.names = FALSE)

# Person 1's mapping uses Patient_id; Person 2's analysis uses Patient_ID.
if (!all(c("Sample", "Patient_id") %in% names(mapping))) {
  stop("Sample-patient mapping must contain 'Sample' and 'Patient_id'.")
}

if (anyNA(mapping$Sample) || anyNA(mapping$Patient_id)) {
  stop("Sample-patient mapping contains missing values.")
}

if (anyDuplicated(mapping$Sample)) {
  stop("Sample-patient mapping contains duplicate Sample values.")
}

malignant_obj <- readRDS(malignant_file)
malignant_meta <- malignant_obj[[]]

if (!"cell_id" %in% names(malignant_meta)) {
  # Seurat objects may use rownames as the stable cell identifier.
  malignant_meta$cell_id <- rownames(malignant_meta)
}

required_meta <- c("Sample", "Cell_subtype")
missing_meta <- setdiff(required_meta, names(malignant_meta))

if (length(missing_meta) > 0) {
  stop("Malignant metadata is missing: ", paste(missing_meta, collapse = ", "))
}

sample_to_patient <- setNames(mapping$Patient_id, mapping$Sample)
malignant_meta$Patient_ID <- unname(
  sample_to_patient[as.character(malignant_meta$Sample)]
)

if (anyNA(malignant_meta$Patient_ID)) {
  stop("Some malignant cells could not be mapped to Patient_ID.")
}

if (length(unique(malignant_meta$Patient_ID)) != 32L) {
  stop("Expected 32 patients after Sample -> Patient mapping.")
}

# Keep the doublet fields when they exist. Do not manufacture a doublet call.
doublet_cols <- intersect(
  c("doublet_score", "doublet_class", "doublet_status"),
  names(malignant_meta)
)

keep_cols <- unique(c(
  "cell_id", "Patient_ID", "Sample", "Cell_subtype", "Cell_type",
  doublet_cols
))

analysis_meta <- malignant_meta[, keep_cols, drop = FALSE]

write.csv(
  analysis_meta,
  file.path(person2_dir, "Person2_CNV_analysis_metadata.csv"),
  row.names = FALSE,
  quote = TRUE
)

cat("\nPerson 2 metadata prepared.\n")
cat("Cells:", nrow(analysis_meta), "\n")
cat("Patients:", length(unique(analysis_meta$Patient_ID)), "\n")
cat("Samples:", length(unique(analysis_meta$Sample)), "\n")
cat("Output: Person2_CNV_analysis_metadata.csv\n")
