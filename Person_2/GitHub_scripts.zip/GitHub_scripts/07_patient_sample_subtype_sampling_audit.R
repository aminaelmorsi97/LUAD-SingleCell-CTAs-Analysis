###############################################################################
# Person 2 — 07_patient_sample_subtype_sampling_audit.R
#
# Purpose:
#   Reconstruct and audit the frozen 2,420-cell inferCNV Pilot at the
#   Patient × Sample × Cell_subtype level.
#
# Important:
#   - The frozen Pilot cell IDs are the source of truth.
#   - This script does NOT re-sample cells.
#   - This script does NOT re-run inferCNV.
#   - This script does NOT assign CNV labels.
#   - No cells outside the frozen Pilot receive a Pilot classification.
#
# Patient mapping:
#   The authoritative 58-sample Sample -> Patient_id mapping is taken from
#   Person 1:
#
#   D:/CTA/person 1/GSE131907_sample_to_patient_mapping.csv
#
#   The 32-sample Person 2 mapping is NOT used here because the reference
#   metadata contains 58 samples.
###############################################################################
# ============================================================================
# 1. PROJECT PATHS
# ============================================================================

project_root <- Sys.getenv(
  "CTA_PROJECT_ROOT",
  unset = "D:/CTA"
)

person1_dir <- file.path(
  project_root,
  "person 1"
)

person2_dir <- file.path(
  project_root,
  "person 2"
)


pilot_file <- file.path(
  person2_dir,
  "20_infercnv_annotations_pilot_2420_used.txt"
)

patient_mapping_file <- file.path(
  person1_dir,
  "GSE131907_sample_to_patient_mapping.csv"
)

malignant_metadata_file <- file.path(
  person2_dir,
  "10_malignant_metadata_with_patient_id.csv"
)

reference_metadata_file <- file.path(
  person2_dir,
  "14_reference_cells_metadata.csv"
)


# ============================================================================
# 2. CHECK REQUIRED FILES
# ============================================================================

required_files <- c(
  pilot_file,
  patient_mapping_file,
  malignant_metadata_file,
  reference_metadata_file
)

missing_files <- required_files[
  !file.exists(required_files)
]


if (length(missing_files) > 0L) {
  
  stop(
    paste(
      "Required file(s) are missing:",
      paste(
        missing_files,
        collapse = "\n"
      ),
      sep = "\n"
    )
  )
  
}


# ============================================================================
# 3. LOAD FROZEN PILOT
# ============================================================================

pilot <- read.delim(
  pilot_file,
  header = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


# Earlier copies used "cell_group".
# Standardize only the working column name.

if (
  "cell_group" %in% names(pilot) &&
  !"group" %in% names(pilot)
) {
  
  names(pilot)[
    names(pilot) == "cell_group"
  ] <- "group"
  
}


if (
  !all(
    c("cell_id", "group") %in%
    names(pilot)
  )
) {
  
  stop(
    "Frozen Pilot must contain cell_id and group."
  )
  
}


pilot <- pilot[
  ,
  c(
    "cell_id",
    "group"
  ),
  drop = FALSE
]


# Remove the accidental duplicated header row that existed
# in an earlier copy.

header_row <- (
  pilot$cell_id == "cell_id" &
    pilot$group == "cell_group"
)


pilot <- pilot[
  !header_row,
  ,
  drop = FALSE
]


# ============================================================================
# 4. VALIDATE FROZEN PILOT
# ============================================================================

if (
  nrow(pilot) != 2420L
) {
  
  stop(
    "Frozen Pilot must contain exactly 2,420 cells. Found: ",
    nrow(pilot)
  )
  
}


if (
  anyNA(pilot$cell_id) ||
  any(pilot$cell_id == "")
) {
  
  stop(
    "Frozen Pilot contains missing or empty cell IDs."
  )
  
}


if (
  anyDuplicated(pilot$cell_id)
) {
  
  stop(
    "Frozen Pilot contains duplicated cell IDs."
  )
  
}


expected_groups <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)


observed_groups <- table(
  pilot$group
)


if (
  !setequal(
    names(observed_groups),
    names(expected_groups)
  )
) {
  
  stop(
    paste(
      "Unexpected Pilot group names:",
      paste(
        names(observed_groups),
        collapse = ", "
      ),
      sep = "\n"
    )
  )
  
}


for (
  group_name in names(expected_groups)
) {
  
  observed_count <- sum(
    pilot$group == group_name,
    na.rm = TRUE
  )
  
  if (
    observed_count !=
    expected_groups[group_name]
  ) {
    
    stop(
      "Pilot count mismatch for ",
      group_name,
      ": expected ",
      expected_groups[group_name],
      ", found ",
      observed_count
    )
    
  }
  
}


# ============================================================================
# 5. LOAD AUTHORITATIVE PERSON 1 SAMPLE -> PATIENT MAPPING
# ============================================================================

patient_mapping <- read.csv(
  patient_mapping_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


required_mapping_columns <- c(
  "Sample",
  "Patient_id"
)


if (
  !all(
    required_mapping_columns %in%
    names(patient_mapping)
  )
) {
  
  stop(
    "Person 1 patient mapping must contain Sample and Patient_id."
  )
  
}


if (
  anyNA(patient_mapping$Sample) ||
  any(patient_mapping$Sample == "")
) {
  
  stop(
    "Person 1 patient mapping contains missing/empty Sample values."
  )
  
}


if (
  anyNA(patient_mapping$Patient_id) ||
  any(patient_mapping$Patient_id == "")
) {
  
  stop(
    "Person 1 patient mapping contains missing/empty Patient_id values."
  )
  
}


if (
  anyDuplicated(patient_mapping$Sample)
) {
  
  stop(
    "Person 1 patient mapping contains duplicated Sample values."
  )
  
}


cat("\n========================================\n")
cat("PERSON 1 SAMPLE -> PATIENT MAPPING\n")
cat("========================================\n")

cat(
  "Mapping rows: ",
  nrow(patient_mapping),
  "\n",
  sep = ""
)

cat(
  "Unique samples: ",
  length(
    unique(
      patient_mapping$Sample
    )
  ),
  "\n",
  sep = ""
)

cat(
  "Unique patients: ",
  length(
    unique(
      patient_mapping$Patient_id
    )
  ),
  "\n",
  sep = ""
)


# The authoritative mapping should contain the complete 58-sample map.

if (
  nrow(patient_mapping) != 58L
) {
  
  stop(
    "Expected the authoritative Person 1 mapping to contain 58 samples. ",
    "Found: ",
    nrow(patient_mapping)
  )
  
}


# ============================================================================
# 6. CREATE SAMPLE -> PATIENT LOOKUP
# ============================================================================

sample_to_patient <- setNames(
  patient_mapping$Patient_id,
  patient_mapping$Sample
)


# ============================================================================
# 7. LOAD MALIGNANT METADATA
# ============================================================================

malignant_metadata <- read.csv(
  malignant_metadata_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


# Standardize Patient_id -> Patient_ID.

if (
  "Patient_id" %in% names(malignant_metadata) &&
  !"Patient_ID" %in% names(malignant_metadata)
) {
  
  names(malignant_metadata)[
    names(malignant_metadata) == "Patient_id"
  ] <- "Patient_ID"
  
}


malignant_required <- c(
  "cell_id",
  "Sample",
  "Patient_ID"
)


missing_malignant <- setdiff(
  malignant_required,
  names(malignant_metadata)
)


if (
  length(missing_malignant) > 0L
) {
  
  stop(
    paste(
      "Malignant metadata is missing:",
      paste(
        missing_malignant,
        collapse = ", "
      ),
      sep = " "
    )
  )
  
}


# ============================================================================
# 8. VALIDATE MALIGNANT SAMPLE -> PATIENT CONSISTENCY
# ============================================================================

malignant_map_check <- unique(
  malignant_metadata[
    ,
    c(
      "Sample",
      "Patient_ID"
    ),
    drop = FALSE
  ]
)


malignant_map_check$mapped_Patient_ID <- unname(
  sample_to_patient[
    malignant_map_check$Sample
  ]
)


mapping_disagreement <- malignant_map_check[
  is.na(
    malignant_map_check$mapped_Patient_ID
  ) |
    malignant_map_check$Patient_ID !=
    malignant_map_check$mapped_Patient_ID,
  ,
  drop = FALSE
]


if (
  nrow(mapping_disagreement) > 0L
) {
  
  stop(
    paste(
      "Malignant metadata disagrees with the authoritative Person 1",
      "Sample -> Patient mapping.",
      "\nProblem samples:",
      paste(
        mapping_disagreement$Sample,
        collapse = ", "
      ),
      sep = "\n"
    )
  )
  
}


# ============================================================================
# 9. LOAD REFERENCE METADATA
# ============================================================================

reference_metadata <- read.csv(
  reference_metadata_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


reference_required <- c(
  "cell_id",
  "Sample"
)


missing_reference <- setdiff(
  reference_required,
  names(reference_metadata)
)


if (
  length(missing_reference) > 0L
) {
  
  stop(
    paste(
      "Reference metadata is missing:",
      paste(
        missing_reference,
        collapse = ", "
      ),
      sep = " "
    )
  )
  
}


# ============================================================================
# 10. MAP ALL 58 REFERENCE SAMPLES TO PATIENT_ID
# ============================================================================

reference_metadata$Patient_ID <- unname(
  sample_to_patient[
    reference_metadata$Sample
  ]
)


missing_reference_patient <- is.na(
  reference_metadata$Patient_ID
)


if (
  any(missing_reference_patient)
) {
  
  missing_samples <- sort(
    unique(
      reference_metadata$Sample[
        missing_reference_patient
      ]
    )
  )
  
  stop(
    paste(
      "Reference samples missing from the authoritative Person 1 mapping:",
      paste(
        missing_samples,
        collapse = ", "
      ),
      sep = "\n"
    )
  )
  
}


cat("\n========================================\n")
cat("REFERENCE SAMPLE -> PATIENT VALIDATION\n")
cat("========================================\n")

cat(
  "Reference cells: ",
  nrow(reference_metadata),
  "\n",
  sep = ""
)

cat(
  "Reference samples: ",
  length(
    unique(
      reference_metadata$Sample
    )
  ),
  "\n",
  sep = ""
)

cat(
  "Mapped reference patients: ",
  length(
    unique(
      reference_metadata$Patient_ID
    )
  ),
  "\n",
  sep = ""
)

cat(
  "Missing Patient_ID: ",
  sum(
    is.na(
      reference_metadata$Patient_ID
    )
  ),
  "\n",
  sep = ""
)


# ============================================================================
# 11. CHECK REFERENCE CELL IDs
# ============================================================================

if (
  anyNA(reference_metadata$cell_id) ||
  any(reference_metadata$cell_id == "")
) {
  
  stop(
    "Reference metadata contains missing or empty cell IDs."
  )
  
}


if (
  anyDuplicated(reference_metadata$cell_id)
) {
  
  stop(
    "Reference metadata contains duplicated cell IDs."
  )
  
}


# ============================================================================
# 12. COMBINE MALIGNANT + REFERENCE METADATA
# ============================================================================

malignant_metadata$metadata_source <- (
  "Malignant metadata"
)

reference_metadata$metadata_source <- (
  "Reference metadata"
)


malignant_working <- malignant_metadata[
  ,
  c(
    "cell_id",
    "Patient_ID",
    "Sample",
    "metadata_source"
  ),
  drop = FALSE
]


reference_working <- reference_metadata[
  ,
  c(
    "cell_id",
    "Patient_ID",
    "Sample",
    "metadata_source"
  ),
  drop = FALSE
]


combined_metadata <- rbind(
  malignant_working,
  reference_working
)


if (
  anyDuplicated(
    combined_metadata$cell_id
  )
) {
  
  stop(
    "Duplicated cell IDs detected in combined malignant/reference metadata."
  )
  
}


# ============================================================================
# 13. MATCH THE FROZEN PILOT TO METADATA
# ============================================================================

pilot_index <- match(
  pilot$cell_id,
  combined_metadata$cell_id
)


if (
  anyNA(pilot_index)
) {
  
  missing_ids <- pilot$cell_id[
    is.na(pilot_index)
  ]
  
  stop(
    paste(
      "Pilot cell(s) could not be matched to metadata.",
      "\nNumber missing:",
      length(missing_ids),
      "\nFirst missing IDs:",
      paste(
        head(
          missing_ids,
          20L
        ),
        collapse = ", "
      ),
      sep = ""
    )
  )
  
}


pilot_metadata <- combined_metadata[
  pilot_index,
  ,
  drop = FALSE
]


# ============================================================================
# 14. VERIFY CELL ORDER
# ============================================================================

if (
  !identical(
    pilot_metadata$cell_id,
    pilot$cell_id
  )
) {
  
  stop(
    "Pilot cell order was not preserved during metadata matching."
  )
  
}


# ============================================================================
# 15. ADD FROZEN PILOT GROUP
# ============================================================================

pilot_metadata$pilot_group <- (
  pilot$group
)


# ============================================================================
# 16. CHECK PATIENT/SAMPLE COMPLETENESS
# ============================================================================

if (
  anyNA(
    pilot_metadata$Patient_ID
  )
) {
  
  stop(
    "Some Pilot cells have missing Patient_ID."
  )
  
}


if (
  anyNA(
    pilot_metadata$Sample
  )
) {
  
  stop(
    "Some Pilot cells have missing Sample."
  )
  
}


# ============================================================================
# 17. CREATE CELL-LEVEL PILOT PROVENANCE TABLE
# ============================================================================

pilot_cell_table <- data.frame(
  cell_id = pilot_metadata$cell_id,
  Patient_ID = pilot_metadata$Patient_ID,
  Sample = pilot_metadata$Sample,
  pilot_group = pilot_metadata$pilot_group,
  metadata_source = pilot_metadata$metadata_source,
  stringsAsFactors = FALSE
)


# ============================================================================
# 18. BUILD PATIENT × SAMPLE × CELL_SUBTYPE TABLE
# ============================================================================

sampling <- as.data.frame(
  table(
    pilot_cell_table$Patient_ID,
    pilot_cell_table$Sample,
    pilot_cell_table$pilot_group,
    dnn = c(
      "Patient_ID",
      "Sample",
      "Cell_subtype"
    )
  ),
  stringsAsFactors = FALSE
)


names(sampling)[
  names(sampling) == "Freq"
] <- "selected_cells"


# Keep only combinations actually represented in the frozen Pilot.

sampling <- sampling[
  sampling$selected_cells > 0L,
  ,
  drop = FALSE
]


sampling$pilot_cells <- (
  sampling$selected_cells
)

sampling$selection_status <- (
  "Frozen Pilot"
)

sampling$random_seed <- (
  NA_character_
)

sampling$seed_note <- paste(
  "Historical random seed is not recoverable from saved artifacts.",
  "Frozen Pilot cell IDs are the reproducibility source of truth."
)


# ============================================================================
# 19. VALIDATE TOTAL PILOT SIZE
# ============================================================================

selected_total <- sum(
  sampling$selected_cells
)

pilot_total <- sum(
  sampling$pilot_cells
)


if (
  selected_total != 2420L
) {
  
  stop(
    "Sampling table contains ",
    selected_total,
    " cells; expected 2,420."
  )
  
}


if (
  pilot_total != 2420L
) {
  
  stop(
    "Pilot cell total is ",
    pilot_total,
    "; expected 2,420."
  )
  
}


# ============================================================================
# 20. VALIDATE PATIENT × SAMPLE × CELL_SUBTYPE UNIQUENESS
# ============================================================================

sampling_key <- sampling[
  ,
  c(
    "Patient_ID",
    "Sample",
    "Cell_subtype"
  ),
  drop = FALSE
]


if (
  anyDuplicated(sampling_key)
) {
  
  stop(
    "Duplicate Patient × Sample × Cell_subtype combinations detected."
  )
  
}


# ============================================================================
# 21. VALIDATE CANONICAL PILOT COMPOSITION
# ============================================================================

composition <- aggregate(
  selected_cells ~ Cell_subtype,
  data = sampling,
  FUN = sum
)


expected_composition <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)


for (
  group_name in names(expected_composition)
) {
  
  observed_count <- sum(
    composition$selected_cells[
      composition$Cell_subtype ==
        group_name
    ],
    na.rm = TRUE
  )
  
  if (
    observed_count !=
    expected_composition[group_name]
  ) {
    
    stop(
      "Composition mismatch for ",
      group_name,
      ": expected ",
      expected_composition[group_name],
      ", found ",
      observed_count
    )
    
  }
  
}


# ============================================================================
# 22. SAVE PATIENT × SAMPLE × CELL_SUBTYPE AUDIT
# ============================================================================

sampling_output <- file.path(
  person2_dir,
  "Person2_Pilot_sampling_by_patient_sample_subtype.csv"
)


write.csv(
  sampling,
  sampling_output,
  row.names = FALSE,
  quote = TRUE
)


# ============================================================================
# 23. SAVE CELL-LEVEL PROVENANCE
# ============================================================================

cell_output <- file.path(
  person2_dir,
  "Person2_Pilot_cell_level_provenance.csv"
)


write.csv(
  pilot_cell_table,
  cell_output,
  row.names = FALSE,
  quote = TRUE
)


# ============================================================================
# 24. FINAL QC
# ============================================================================

cat("\n")
cat("========================================\n")
cat("PERSON 2 — PILOT SAMPLING AUDIT\n")
cat("========================================\n")

cat(
  "Frozen Pilot cells: ",
  nrow(pilot),
  "\n",
  sep = ""
)

cat(
  "Observation cells: ",
  sum(
    pilot$group != "Reference"
  ),
  "\n",
  sep = ""
)

cat(
  "Reference cells: ",
  sum(
    pilot$group == "Reference"
  ),
  "\n",
  sep = ""
)

cat(
  "Patients represented: ",
  length(
    unique(
      pilot_cell_table$Patient_ID
    )
  ),
  "\n",
  sep = ""
)

cat(
  "Samples represented: ",
  length(
    unique(
      pilot_cell_table$Sample
    )
  ),
  "\n",
  sep = ""
)

cat(
  "Person 1 mapping samples: ",
  nrow(patient_mapping),
  "\n",
  sep = ""
)

cat(
  "Historical random seed: not recoverable.\n"
)

cat(
  "Frozen Pilot cell IDs are the reproducibility source of truth.\n"
)

cat("\nPilot composition:\n")

print(composition)

cat(
  "\nSampling audit saved to:\n",
  sampling_output,
  "\n",
  sep = ""
)

cat(
  "\nCell-level provenance saved to:\n",
  cell_output,
  "\n",
  sep = ""
)

cat(
  "\nSTATUS: PASS\n"
)

cat("========================================\n")
