# Person 2 — 03_build_patient_reference_and_pilot_groups.R
#
# Purpose:
# Freeze and validate the canonical 2,420-cell Pilot used for the
# Person 2 inferCNV sensitivity analysis.
#
# The Pilot was already selected and analyzed.
# This script does NOT perform new random sampling.
#
# The frozen cell IDs are treated as the reproducibility source
# because the historical random seed was not recoverable.

# -------------------------------------------------------------------------
# 1. Project paths
# -------------------------------------------------------------------------

project_root <- Sys.getenv(
  "CTA_PROJECT_ROOT",
  unset = "D:/CTA"
)

person2_dir <- file.path(
  project_root,
  "person 2"
)

pilot_file <- file.path(
  person2_dir,
  "20_infercnv_annotations_pilot_2420_used.txt"
)


# -------------------------------------------------------------------------
# 2. Load the frozen Pilot
# -------------------------------------------------------------------------

if (!file.exists(pilot_file)) {
  stop(
    "Missing frozen Pilot annotation file:\n",
    pilot_file
  )
}

pilot <- read.delim(
  pilot_file,
  header = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


# -------------------------------------------------------------------------
# 3. Standardize the group column
# -------------------------------------------------------------------------
#
# Earlier versions of the frozen annotation used "cell_group".
# The biological labels themselves are not changed.


if (
  "cell_group" %in% names(pilot) &&
  !"group" %in% names(pilot)
) {
  names(pilot)[
    names(pilot) == "cell_group"
  ] <- "group"
}


if (!all(c("cell_id", "group") %in% names(pilot))) {
  stop(
    "Pilot annotation must contain 'cell_id' and 'group'."
  )
}

pilot <- pilot[
  ,
  c("cell_id", "group"),
  drop = FALSE
]


# -------------------------------------------------------------------------
# 4. Remove the known accidental duplicated header row
# -------------------------------------------------------------------------
#
# One earlier copy contained a single row where the column names
# were repeated as data. Only that exact accidental row is removed.


is_header <- (
  pilot$cell_id == "cell_id" &
    pilot$group == "cell_group"
)

pilot <- pilot[
  !is_header,
  ,
  drop = FALSE
]


# -------------------------------------------------------------------------
# 5. Define the canonical Pilot composition
# -------------------------------------------------------------------------

expected <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)


# -------------------------------------------------------------------------
# 6. Validate Pilot size
# -------------------------------------------------------------------------

if (nrow(pilot) != 2420L) {
  stop(
    "Canonical Pilot must contain exactly 2,420 cells. ",
    "Found: ",
    nrow(pilot)
  )
}


# -------------------------------------------------------------------------
# 7. Validate group composition
# -------------------------------------------------------------------------

observed <- table(pilot$group)

if (!setequal(
  names(observed),
  names(expected)
)) {
  stop(
    "Pilot contains unexpected group names."
  )
}

for (group_name in names(expected)) {
  
  if (
    unname(observed[group_name]) !=
    expected[group_name]
  ) {
    
    stop(
      "Pilot group count mismatch for '",
      group_name,
      "': expected ",
      expected[group_name],
      ", found ",
      unname(observed[group_name]),
      "."
    )
  }
}


# -------------------------------------------------------------------------
# 8. Validate cell IDs
# -------------------------------------------------------------------------

if (anyNA(pilot$cell_id)) {
  stop("Pilot contains missing cell IDs.")
}

if (anyDuplicated(pilot$cell_id)) {
  stop(
    "Pilot contains duplicated cell IDs."
  )
}


# -------------------------------------------------------------------------
# 9. Save the canonical Pilot annotation
# -------------------------------------------------------------------------

canonical_file <- file.path(
  person2_dir,
  "Person2_canonical_pilot_annotations.txt"
)

write.table(
  pilot,
  canonical_file,
  sep = "\t",
  row.names = FALSE,
  quote = FALSE
)


# -------------------------------------------------------------------------
# 10. Final report
# -------------------------------------------------------------------------

cat("\n")
cat("========================================\n")
cat("PERSON 2 — CANONICAL PILOT\n")
cat("========================================\n")

cat(
  "Pilot cells: 2,420\n"
)

cat(
  "Malignant cells: ",
  expected["Malignant cells"],
  "\n",
  sep = ""
)

cat(
  "Reference cells: ",
  expected["Reference"],
  "\n",
  sep = ""
)

cat(
  "tS1 cells: ",
  expected["tS1"],
  "\n",
  sep = ""
)

cat(
  "tS2 cells: ",
  expected["tS2"],
  "\n",
  sep = ""
)

cat(
  "tS3 cells: ",
  expected["tS3"],
  "\n",
  sep = ""
)

cat(
  "Historical random seed: ",
  "not recoverable from saved artifacts.\n",
  sep = ""
)

cat(
  "Frozen cell IDs are the reproducibility source of truth.\n"
)

cat(
  "Canonical file:\n",
  canonical_file,
  "\n",
  sep = ""
)

cat(
  "Status: PASS\n"
)

cat("========================================\n")