###############################################################################
# 09_final_pilot_handoff.R
#
# Purpose:
#   Create the final mentor-facing filename without changing cell IDs or
#   biological classifications.
###############################################################################


project_root <- Sys.getenv("CTA_PROJECT_ROOT", unset = "D:/CTA")
person2_dir <- file.path(project_root, "person 2")

source_file <- file.path(
  person2_dir,
  "25_Person2_final_malignancy_handoff.csv"
)

target_file <- file.path(
  person2_dir,
  "Person2_inferCNV_pilot_sensitivity_handoff.csv"
)

if (!file.exists(source_file)) {
  source_file <- file.path(
    person2_dir,
    "Person2_inferCNV_pilot_sensitivity_handoff.csv"
  )
}

if (!file.exists(source_file)) {
  stop("No completed Pilot handoff table was found.")
}

handoff <- read.csv(
  source_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

if (nrow(handoff) != 2420L) {
  stop("Final Pilot handoff must contain exactly 2,420 cells.")
}

if (!"cell_id" %in% names(handoff)) {
  stop("Final handoff must preserve cell_id.")
}

if (anyDuplicated(handoff$cell_id)) {
  stop("Final handoff contains duplicated cell IDs.")
}

if (!"final_malignancy_class" %in% names(handoff)) {
  stop("Final handoff is missing final_malignancy_class.")
}

supported <- sum(
  handoff$final_malignancy_class == "Malignant supported",
  na.rm = TRUE
)

if (supported != 889L) {
  stop("Expected 889 Malignant supported cells.")
}

write.csv(
  handoff,
  target_file,
  row.names = FALSE,
  quote = TRUE
)

cat("\n========================================\n")
cat("FINAL PILOT HANDOFF READY\n")
cat("========================================\n")
cat("File:", target_file, "\n")
cat("Cells:", nrow(handoff), "\n")
cat("Malignant supported:", supported, "\n")
cat("CNV outside Pilot: not assigned\n")
cat("Status: PASS\n")
