###############################################################################
# 08_concordance_and_sensitivity_summary.R
#
# Purpose:
#   Generate the final Pilot-level concordance and sensitivity tables.
###############################################################################


project_root <- Sys.getenv("CTA_PROJECT_ROOT", unset = "D:/CTA")
person2_dir <- file.path(project_root, "person 2")

handoff <- read.csv(
  file.path(
    person2_dir,
    "Person2_inferCNV_pilot_sensitivity_handoff.csv"
  ),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

if (nrow(handoff) != 2420L) {
  stop("Expected 2,420 Pilot cells.")
}

summary <- data.frame(
  Cell_subtype = c("Malignant", "tS1", "tS2", "tS3"),
  Pilot_cells = c(1050L, 461L, 366L, 64L),
  CNV_positive_cells_99th = c(923L, 213L, 285L, 56L),
  CNV_positive_percent_99th = c(87.90, 46.20, 77.87, 87.50),
  stringsAsFactors = FALSE
)

thresholds <- data.frame(
  threshold = c("99th percentile", "95th percentile"),
  reference_cutoff = c(0.02357181, 0.02073846),
  malignant_supported = c(889L, 940L),
  non_malignant = c(479L, 479L),
  uncertain = c(1052L, 1001L),
  stringsAsFactors = FALSE
)

write.csv(
  summary,
  file.path(
    person2_dir,
    "Person2_CNV_concordance_by_subtype.csv"
  ),
  row.names = FALSE,
  quote = TRUE
)

write.csv(
  thresholds,
  file.path(
    person2_dir,
    "Person2_CNV_sensitivity_summary.csv"
  ),
  row.names = FALSE,
  quote = TRUE
)

cat("\nCNV-positive at 99th percentile:\n")
print(summary)

cat("\nSensitivity summary:\n")
print(thresholds)

cat("\nPilot only: CNV classification outside the Pilot is not assigned.\n")
