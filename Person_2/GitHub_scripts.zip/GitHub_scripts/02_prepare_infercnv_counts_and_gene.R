###############################################################################
# 02_prepare_infercnv_counts_and_gene_order.R
#
# Purpose:
#   Prepare the exact 19,532-gene count matrix and the matching hg38 gene-order
#   file used by the completed Pilot.
#
# This script deliberately validates dimensions and names before any
# inferCNV step. It does not silently reorder genes or cells.
###############################################################################


project_root <- Sys.getenv("CTA_PROJECT_ROOT", unset = "D:/CTA")
person2_dir <- file.path(project_root, "person 2")

counts_file <- file.path(
  person2_dir,
  "15_infercnv_counts_19532_genes.rds"
)

gene_order_file <- file.path(
  person2_dir,
  "18_infercnv_gene_order_clean.txt"
)

if (!file.exists(counts_file)) stop("Missing counts file: ", counts_file)
if (!file.exists(gene_order_file)) stop("Missing gene-order file: ", gene_order_file)

counts <- readRDS(counts_file)

gene_order <- read.table(
  gene_order_file,
  header = FALSE,
  sep = "\t",
  stringsAsFactors = FALSE,
  check.names = FALSE,
  col.names = c("gene", "chr", "start", "end")
)

if (!identical(dim(counts), c(19532L, 31136L))) {
  stop(
    "Expected 19,532 x 31,136 counts; observed ",
    paste(dim(counts), collapse = " x ")
  )
}

if (nrow(gene_order) != 19532L) {
  stop("Gene-order file must contain exactly 19,532 genes.")
}

if (anyDuplicated(gene_order$gene)) {
  stop("Gene-order file contains duplicated genes.")
}

valid_chr <- c(as.character(1:22), "X", "Y")
bad_chr <- setdiff(unique(gene_order$chr), valid_chr)

if (length(bad_chr) > 0) {
  stop(
    "Unexpected chromosome values: ",
    paste(bad_chr, collapse = ", ")
  )
}

if (!identical(rownames(counts), gene_order$gene)) {
  stop("Gene order and count-matrix row names are not identical.")
}

if (anyDuplicated(colnames(counts))) {
  stop("Count matrix contains duplicated cell IDs.")
}

cat("\n========================================\n")
cat("inferCNV INPUTS READY\n")
cat("========================================\n")
cat("Counts:", nrow(counts), "genes x", ncol(counts), "cells\n")
cat("Gene order:", nrow(gene_order), "genes\n")
cat("Cell IDs:", length(unique(colnames(counts))), "\n")
cat("Status: PASS\n")
