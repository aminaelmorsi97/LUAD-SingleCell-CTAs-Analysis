# ============================================================
# 08_CNV_burden_and_sensitivity.R
#
# Project:
# Single-Cell Characterization of Cancer–Testis Antigen Expression
# and Metastasis-Associated Malignant Cell States in NSCLC
#
# Analysis:
# Canonical inferCNV pilot burden and sensitivity analysis
#
# IMPORTANT SCIENTIFIC SCOPE:
# This analysis uses the canonical 2,420-cell inferCNV pilot.
# It is a validation subset and does NOT represent the full
# 31,136-cell malignant-cell dataset.
#
# Canonical pilot annotation:
# 20_infercnv_annotations_pilot_2420_used.txt
#
# Canonical handoff:
# Person2_inferCNV_pilot_sensitivity_handoff.csv
#
# Canonical thresholds:
# 95th percentile = 0.02073846
# 99th percentile = 0.02357181
#
# CNV classification:
#   CNV_negative  : CNV_score < 95th percentile
#   CNV_uncertain : 95th <= CNV_score < 99th percentile
#   CNV_positive  : CNV_score >= 99th percentile
#
# No inferCNV rerun is performed in this script.
# ============================================================


# ============================================================
# 01. Configuration
# ============================================================

options(stringsAsFactors = FALSE)

person2_dir <- "D:/CTA/person 2"

handoff_file <- file.path(
  person2_dir,
  "Person2_inferCNV_pilot_sensitivity_handoff.csv"
)

annotation_file <- file.path(
  person2_dir,
  "20_infercnv_annotations_pilot_2420_used.txt"
)

output_burden_file <- file.path(
  person2_dir,
  "Person2_CNV_burden_by_cell.csv"
)

output_positive_file <- file.path(
  person2_dir,
  "Person2_CNV_positive_by_cell_subtype_99th.csv"
)

output_sensitivity_file <- file.path(
  person2_dir,
  "Person2_CNV_sensitivity_thresholds.csv"
)


# ============================================================
# 02. Validate input files
# ============================================================

required_files <- c(
  handoff_file,
  annotation_file
)

missing_files <- required_files[
  !file.exists(required_files)
]

if (length(missing_files) > 0) {
  
  stop(
    paste(
      "Required input file(s) not found:",
      paste(missing_files, collapse = "\n")
    )
  )
}


# ============================================================
# 03. Load canonical handoff
# ============================================================

cnv_results <- read.csv(
  handoff_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

cat("\n============================================================\n")
cat("CANONICAL CNV HANDOFF\n")
cat("============================================================\n\n")

cat(
  "Rows:",
  nrow(cnv_results),
  "\n"
)

cat(
  "Columns:",
  ncol(cnv_results),
  "\n\n"
)

print(
  colnames(cnv_results)
)


# ============================================================
# 04. Validate required columns
# ============================================================

required_columns <- c(
  "cell_id",
  "Patient_ID",
  "Sample",
  "Cell_subtype",
  "CNV_score",
  "CNV_label"
)

missing_columns <- setdiff(
  required_columns,
  colnames(cnv_results)
)

if (length(missing_columns) > 0) {
  
  stop(
    paste(
      "Missing required column(s):",
      paste(missing_columns, collapse = ", ")
    )
  )
}


# ============================================================
# 05. Validate canonical pilot size
# ============================================================

expected_n_cells <- 2420L

if (nrow(cnv_results) != expected_n_cells) {
  
  stop(
    paste(
      "Expected",
      expected_n_cells,
      "canonical pilot cells but found",
      nrow(cnv_results),
      "rows."
    )
  )
  
} else {
  
  cat(
    "\nPASS:",
    expected_n_cells,
    "canonical pilot cells detected.\n"
  )
}


# ============================================================
# 06. Reconstruct analysis group
#
# Cell_subtype contains:
#   Malignant cells
#   tS1
#   tS2
#   tS3
#
# Reference cells have NA in Cell_subtype.
# Therefore NA is explicitly assigned to Reference.
# ============================================================

cnv_results$group <- cnv_results$Cell_subtype

reference_na_count <- sum(
  is.na(cnv_results$group)
)

if (reference_na_count != 479L) {
  
  stop(
    paste(
      "Expected 479 Reference cells represented by NA in Cell_subtype,",
      "but found",
      reference_na_count,
      "."
    )
  )
}

cnv_results$group[
  is.na(cnv_results$group)
] <- "Reference"


# ============================================================
# 07. Validate canonical group counts
# ============================================================

expected_groups <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)

observed_groups <- table(
  factor(
    cnv_results$group,
    levels = names(expected_groups)
  )
)

cat("\n============================================================\n")
cat("CANONICAL PILOT GROUP COUNTS\n")
cat("============================================================\n\n")

print(observed_groups)

if (
  !all(
    as.integer(observed_groups) ==
    unname(expected_groups)
  )
) {
  
  stop(
    "Canonical pilot group counts do not match expected counts."
  )
  
} else {
  
  cat(
    "\nPASS: Canonical group counts validated.\n"
  )
}


# ============================================================
# 08. Validate CNV score
# ============================================================

if (!is.numeric(cnv_results$CNV_score)) {
  
  cnv_results$CNV_score <- as.numeric(
    cnv_results$CNV_score
  )
}

if (anyNA(cnv_results$CNV_score)) {
  
  stop(
    paste(
      "CNV_score contains",
      sum(is.na(cnv_results$CNV_score)),
      "NA values."
    )
  )
}

if (any(!is.finite(cnv_results$CNV_score))) {
  
  stop(
    "CNV_score contains non-finite values."
  )
}


# ============================================================
# 09. Canonical CNV thresholds
# ============================================================

threshold_95 <- 0.02073846
threshold_99 <- 0.02357181

cat("\n============================================================\n")
cat("CANONICAL CNV THRESHOLDS\n")
cat("============================================================\n\n")

cat(
  "95th percentile:",
  threshold_95,
  "\n"
)

cat(
  "99th percentile:",
  threshold_99,
  "\n"
)


# ============================================================
# 10. Validate canonical three-tier CNV classification
#
# The handoff uses three categories:
#
#   CNV_negative
#   CNV_uncertain
#   CNV_positive
#
# The previous script incorrectly compared this three-tier
# classification against a binary 99th-percentile label.
# ============================================================

expected_cnv_label <- ifelse(
  cnv_results$CNV_score >= threshold_99,
  "CNV_positive",
  ifelse(
    cnv_results$CNV_score >= threshold_95,
    "CNV_uncertain",
    "CNV_negative"
  )
)

cat("\n============================================================\n")
cat("CANONICAL CNV LABEL VALIDATION\n")
cat("============================================================\n\n")

label_comparison <- table(
  Existing_label = cnv_results$CNV_label,
  Expected_label = expected_cnv_label,
  useNA = "ifany"
)

print(label_comparison)

label_mismatch <- (
  cnv_results$CNV_label !=
    expected_cnv_label
)

n_label_mismatch <- sum(
  label_mismatch,
  na.rm = TRUE
)

cat(
  "\nNumber of label mismatches:",
  n_label_mismatch,
  "\n"
)

if (n_label_mismatch > 0) {
  
  mismatch_table <- cnv_results[
    label_mismatch,
    c(
      "cell_id",
      "Patient_ID",
      "Sample",
      "Cell_subtype",
      "CNV_score",
      "CNV_label"
    ),
    drop = FALSE
  ]
  
  cat("\nFirst mismatching cells:\n\n")
  
  print(
    head(
      mismatch_table,
      30
    )
  )
  
  stop(
    paste(
      "Canonical CNV_label validation failed:",
      n_label_mismatch,
      "mismatches detected."
    )
  )
  
} else {
  
  cat(
    "\nPASS: Existing CNV_label exactly matches the",
    "canonical three-tier classification.\n"
  )
}


# ============================================================
# 11. Validate overall canonical CNV label counts
# ============================================================

expected_label_counts <- c(
  CNV_negative  = 786L,
  CNV_uncertain = 152L,
  CNV_positive  = 1482L
)

observed_label_counts <- table(
  factor(
    cnv_results$CNV_label,
    levels = names(expected_label_counts)
  )
)

cat("\n============================================================\n")
cat("OVERALL CNV LABEL COUNTS\n")
cat("============================================================\n\n")

print(observed_label_counts)

if (
  !all(
    as.integer(observed_label_counts) ==
    unname(expected_label_counts)
  )
) {
  
  stop(
    "Overall CNV label counts do not match the canonical 2,420-cell handoff."
  )
  
} else {
  
  cat(
    "\nPASS: Overall CNV label counts match the canonical handoff.\n"
  )
}


# ============================================================
# 12. Validate canonical 99th-percentile positive counts
# ============================================================

expected_positive_by_group <- c(
  "Malignant cells" = 923L,
  "Reference"       = 5L,
  "tS1"             = 213L,
  "tS2"             = 285L,
  "tS3"             = 56L
)

observed_positive_by_group <- table(
  factor(
    cnv_results$group[
      cnv_results$CNV_label == "CNV_positive"
    ],
    levels = names(expected_positive_by_group)
  )
)

cat("\n============================================================\n")
cat("99TH-PERCENTILE CNV-POSITIVE COUNTS\n")
cat("============================================================\n\n")

print(observed_positive_by_group)

if (
  !all(
    as.integer(observed_positive_by_group) ==
    unname(expected_positive_by_group)
  )
) {
  
  stop(
    "99th-percentile CNV-positive counts do not match the canonical handoff."
  )
  
} else {
  
  cat(
    "\nPASS: 99th-percentile CNV-positive counts match the canonical handoff.\n"
  )
}


# ============================================================
# 13. Derive binary sensitivity classifications
# ============================================================

cnv_results$CNV_positive_95th <- (
  cnv_results$CNV_score >= threshold_95
)

cnv_results$CNV_positive_99th <- (
  cnv_results$CNV_score >= threshold_99
)


# ============================================================
# 14. Sensitivity summary
# ============================================================

n_positive_95 <- sum(
  cnv_results$CNV_positive_95th,
  na.rm = TRUE
)

n_positive_99 <- sum(
  cnv_results$CNV_positive_99th,
  na.rm = TRUE
)

n_uncertain_between_thresholds <- sum(
  cnv_results$CNV_positive_95th &
    !cnv_results$CNV_positive_99th,
  na.rm = TRUE
)

cat("\n============================================================\n")
cat("CNV SENSITIVITY SUMMARY\n")
cat("============================================================\n\n")

cat(
  "95th-percentile positive cells:",
  n_positive_95,
  "\n"
)

cat(
  "99th-percentile positive cells:",
  n_positive_99,
  "\n"
)

cat(
  "Intermediate cells (95th to <99th):",
  n_uncertain_between_thresholds,
  "\n"
)


# ============================================================
# 15. Create cell-level CNV burden table
# ============================================================

cnv_burden <- cnv_results[
  ,
  c(
    "cell_id",
    "Patient_ID",
    "Sample",
    "Cell_subtype",
    "Cell_type",
    "doublet_score",
    "doublet_class",
    "CNV_score",
    "CNV_label",
    "final_malignancy_class",
    "malignancy_stringent",
    "malignancy_expanded",
    "CNV_analysis_scope",
    "malignancy_scope",
    "outside_pilot_classification"
  ),
  drop = FALSE
]

cnv_burden$group <- cnv_results$group

cnv_burden$CNV_positive_95th <- (
  cnv_results$CNV_positive_95th
)

cnv_burden$CNV_positive_99th <- (
  cnv_results$CNV_positive_99th
)


# ============================================================
# 16. Export cell-level CNV burden
# ============================================================

write.csv(
  cnv_burden,
  output_burden_file,
  row.names = FALSE
)

cat(
  "\nSaved:",
  output_burden_file,
  "\n"
)


# ============================================================
# 17. Create 99th-percentile positive-cell summary
# ============================================================

positive_99 <- cnv_results[
  cnv_results$CNV_positive_99th,
  ,
  drop = FALSE
]

positive_by_group <- aggregate(
  cell_id ~ group,
  data = positive_99,
  FUN = length
)

colnames(positive_by_group)[
  colnames(positive_by_group) == "cell_id"
] <- "CNV_positive_cells_99th"

positive_by_group$Total_cells <- as.integer(
  table(
    factor(
      cnv_results$group,
      levels = names(expected_groups)
    )
  )
)

positive_by_group$CNV_positive_fraction_99th <- (
  positive_by_group$CNV_positive_cells_99th /
    positive_by_group$Total_cells
)

positive_by_group$CNV_positive_percent_99th <- (
  100 *
    positive_by_group$CNV_positive_fraction_99th
)

positive_by_group <- positive_by_group[
  match(
    names(expected_groups),
    positive_by_group$group
  ),
  ,
  drop = FALSE
]

positive_by_group$group <- factor(
  positive_by_group$group,
  levels = names(expected_groups)
)

positive_by_group <- positive_by_group[
  order(positive_by_group$group),
  ,
  drop = FALSE
]

positive_by_group$group <- as.character(
  positive_by_group$group
)


# ============================================================
# 18. Export 99th-percentile positive-cell summary
# ============================================================

write.csv(
  positive_by_group,
  output_positive_file,
  row.names = FALSE
)

cat(
  "Saved:",
  output_positive_file,
  "\n"
)


# ============================================================
# 19. Create sensitivity threshold summary
# ============================================================

sensitivity_summary <- data.frame(
  Threshold = c(
    "95th_percentile",
    "99th_percentile"
  ),
  CNV_score_threshold = c(
    threshold_95,
    threshold_99
  ),
  CNV_positive_cells = c(
    n_positive_95,
    n_positive_99
  ),
  CNV_positive_percent = c(
    100 * n_positive_95 / nrow(cnv_results),
    100 * n_positive_99 / nrow(cnv_results)
  ),
  stringsAsFactors = FALSE
)

# Add intermediate category information.
intermediate_row <- data.frame(
  Threshold = "95th_to_<99th_intermediate",
  CNV_score_threshold = NA_real_,
  CNV_positive_cells = n_uncertain_between_thresholds,
  CNV_positive_percent =
    100 *
    n_uncertain_between_thresholds /
    nrow(cnv_results),
  stringsAsFactors = FALSE
)

sensitivity_summary <- rbind(
  sensitivity_summary,
  intermediate_row
)


# ============================================================
# 20. Export sensitivity summary
# ============================================================

write.csv(
  sensitivity_summary,
  output_sensitivity_file,
  row.names = FALSE
)

cat(
  "Saved:",
  output_sensitivity_file,
  "\n"
)


# ============================================================
# 21. Final validation checks
# ============================================================

cat("\n============================================================\n")
cat("FINAL VALIDATION\n")
cat("============================================================\n\n")


# Total cells
if (nrow(cnv_results) != 2420L) {
  stop("Final validation failed: incorrect number of pilot cells.")
}


# Group totals
if (
  sum(
    table(
      factor(
        cnv_results$group,
        levels = names(expected_groups)
      )
    )
  ) != 2420L
) {
  
  stop(
    "Final validation failed: group totals do not sum to 2,420."
  )
}


# CNV labels
if (
  sum(
    table(
      factor(
        cnv_results$CNV_label,
        levels = names(expected_label_counts)
      )
    )
  ) != 2420L
) {
  
  stop(
    "Final validation failed: CNV label totals do not sum to 2,420."
  )
}


# Threshold consistency
if (
  n_positive_95 <
  n_positive_99
) {
  
  stop(
    "Final validation failed: 95th-percentile positives cannot be fewer than 99th-percentile positives."
  )
}


# Intermediate category
if (
  n_positive_95 -
  n_positive_99 !=
  n_uncertain_between_thresholds
) {
  
  stop(
    "Final validation failed: sensitivity counts are inconsistent."
  )
}


# Output files
output_files <- c(
  output_burden_file,
  output_positive_file,
  output_sensitivity_file
)

missing_outputs <- output_files[
  !file.exists(output_files)
]

if (length(missing_outputs) > 0) {
  
  stop(
    paste(
      "Final validation failed: output file(s) missing:",
      paste(missing_outputs, collapse = "\n")
    )
  )
}


# ============================================================
# 22. Final report
# ============================================================

cat("\n============================================================\n")
cat("CNV BURDEN AND SENSITIVITY ANALYSIS COMPLETE\n")
cat("============================================================\n\n")

cat(
  "Analysis scope:",
  "inferCNV pilot only (2,420 cells)\n"
)

cat(
  "Full malignant dataset:",
  "31,136 cells (NOT analyzed by this pilot script)\n\n"
)

cat(
  "95th percentile threshold:",
  threshold_95,
  "\n"
)

cat(
  "99th percentile threshold:",
  threshold_99,
  "\n\n"
)

cat(
  "CNV-negative:",
  expected_label_counts["CNV_negative"],
  "\n"
)

cat(
  "CNV-uncertain:",
  expected_label_counts["CNV_uncertain"],
  "\n"
)

cat(
  "CNV-positive:",
  expected_label_counts["CNV_positive"],
  "\n\n"
)

cat(
  "95th-percentile positive:",
  n_positive_95,
  "\n"
)

cat(
  "99th-percentile positive:",
  n_positive_99,
  "\n"
)

cat(
  "Intermediate 95th-to-<99th:",
  n_uncertain_between_thresholds,
  "\n\n"
)

cat(
  "All validation checks passed.\n"
)

cat(
  "Output files:\n"
)

cat(
  "1.",
  output_burden_file,
  "\n"
)

cat(
  "2.",
  output_positive_file,
  "\n"
)

cat(
  "3.",
  output_sensitivity_file,
  "\n"
)

