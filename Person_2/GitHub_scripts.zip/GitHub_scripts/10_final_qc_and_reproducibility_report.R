###############################################################################
# 10_final_qc_and_reproducibility_report.R
#
# Purpose:
#   Final QC and reproducibility check for the Person 2 inferCNV pilot.
#
# Scientific scope:
#   This report covers the canonical 2,420-cell inferCNV pilot only.
#   It does NOT assign malignancy status outside the pilot.
###############################################################################

project_root <- Sys.getenv(
  "CTA_PROJECT_ROOT",
  unset = "D:/CTA"
)

person2_dir <- file.path(project_root, "person 2")

handoff_file <- file.path(
  person2_dir,
  "Person2_inferCNV_pilot_sensitivity_handoff.csv"
)

###############################################################################
# 1. Load canonical handoff
###############################################################################

if (!file.exists(handoff_file)) {
  stop(
    "Canonical handoff file not found:\n",
    handoff_file
  )
}

handoff <- read.csv(
  handoff_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

###############################################################################
# 2. Required columns
#
# Scope fields are NOT required because they are documented by this
# reproducibility report rather than stored in the canonical handoff CSV.
###############################################################################

required_columns <- c(
  "cell_id",
  "Sample",
  "Cell_subtype",
  "CNV_score",
  "CNV_label",
  "final_malignancy_class",
  "malignancy_stringent",
  "malignancy_expanded"
)

missing_columns <- setdiff(
  required_columns,
  colnames(handoff)
)

if (length(missing_columns) > 0) {
  
  stop(
    paste(
      "Missing required column(s):",
      paste(missing_columns, collapse = ", ")
    )
  )
}

###############################################################################
# 3. Pilot size and cell ID checks
###############################################################################

if (nrow(handoff) != 2420L) {
  stop("Canonical pilot handoff must contain exactly 2,420 cells.")
}

if (any(is.na(handoff$cell_id)) ||
    any(handoff$cell_id == "")) {
  stop("Missing cell IDs detected.")
}

if (anyDuplicated(handoff$cell_id)) {
  stop("Duplicate cell IDs detected.")
}

###############################################################################
# 4. Reconstruct pilot groups
#
# In the canonical handoff, Cell_subtype = NA represents Reference cells.
###############################################################################

group <- handoff$Cell_subtype

group[is.na(group)] <- "Reference"

expected_group_counts <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)

observed_group_counts <- table(group)

for (grp in names(expected_group_counts)) {
  
  observed <- ifelse(
    grp %in% names(observed_group_counts),
    unname(observed_group_counts[grp]),
    0L
  )
  
  if (observed != expected_group_counts[grp]) {
    stop(
      "Unexpected pilot group count for ",
      grp,
      ": observed ",
      observed,
      ", expected ",
      expected_group_counts[grp]
    )
  }
}

###############################################################################
# 5. Final malignancy-class checks
###############################################################################

expected_final_class <- c(
  "Malignant supported" = 889L,
  "Non-malignant"       = 479L,
  "Uncertain"           = 1052L
)

observed_final_class <- table(
  handoff$final_malignancy_class
)

for (cls in names(expected_final_class)) {
  
  observed <- ifelse(
    cls %in% names(observed_final_class),
    unname(observed_final_class[cls]),
    0L
  )
  
  if (observed != expected_final_class[cls]) {
    stop(
      "Unexpected final malignancy-class count for ",
      cls,
      ": observed ",
      observed,
      ", expected ",
      expected_final_class[cls]
    )
  }
}

###############################################################################
# 6. Stringent sensitivity check
###############################################################################

expected_stringent <- c(
  "Malignant supported" = 889L,
  "Non-malignant"       = 479L,
  "Uncertain"           = 1052L
)

observed_stringent <- table(
  handoff$malignancy_stringent
)

for (cls in names(expected_stringent)) {
  
  observed <- ifelse(
    cls %in% names(observed_stringent),
    unname(observed_stringent[cls]),
    0L
  )
  
  if (observed != expected_stringent[cls]) {
    stop(
      "Unexpected stringent classification count for ",
      cls,
      ": observed ",
      observed,
      ", expected ",
      expected_stringent[cls]
    )
  }
}

###############################################################################
# 7. Expanded sensitivity check
###############################################################################

expected_expanded <- c(
  "Malignant supported" = 940L,
  "Non-malignant"       = 479L,
  "Uncertain"           = 1001L
)

observed_expanded <- table(
  handoff$malignancy_expanded
)

for (cls in names(expected_expanded)) {
  
  observed <- ifelse(
    cls %in% names(observed_expanded),
    unname(observed_expanded[cls]),
    0L
  )
  
  if (observed != expected_expanded[cls]) {
    stop(
      "Unexpected expanded classification count for ",
      cls,
      ": observed ",
      observed,
      ", expected ",
      expected_expanded[cls]
    )
  }
}

###############################################################################
# 8. Canonical CNV thresholds
###############################################################################

threshold_95 <- 0.02073846
threshold_99 <- 0.02357181

if (threshold_95 >= threshold_99) {
  stop("Invalid CNV thresholds.")
}

###############################################################################
# 9. CNV score validation
###############################################################################

if (!is.numeric(handoff$CNV_score)) {
  stop("CNV_score must be numeric.")
}

if (any(!is.finite(handoff$CNV_score))) {
  stop("CNV_score contains non-finite values.")
}

###############################################################################
# 10. Validate canonical 3-tier CNV labels
###############################################################################

expected_cnv_label <- ifelse(
  handoff$CNV_score >= threshold_99,
  "CNV_positive",
  ifelse(
    handoff$CNV_score >= threshold_95,
    "CNV_uncertain",
    "CNV_negative"
  )
)

cnv_mismatch <- sum(
  handoff$CNV_label != expected_cnv_label,
  na.rm = TRUE
)

if (cnv_mismatch != 0L) {
  stop(
    "CNV_label does not match the canonical 95th/99th percentile ",
    "three-tier definition. Mismatches: ",
    cnv_mismatch
  )
}

###############################################################################
# 11. Overall CNV counts
###############################################################################

expected_cnv_counts <- c(
  "CNV_negative"  = 786L,
  "CNV_uncertain" = 152L,
  "CNV_positive"  = 1482L
)

observed_cnv_counts <- table(
  handoff$CNV_label
)

for (label in names(expected_cnv_counts)) {
  
  observed <- ifelse(
    label %in% names(observed_cnv_counts),
    unname(observed_cnv_counts[label]),
    0L
  )
  
  if (observed != expected_cnv_counts[label]) {
    stop(
      "Unexpected CNV count for ",
      label,
      ": observed ",
      observed,
      ", expected ",
      expected_cnv_counts[label]
    )
  }
}

###############################################################################
# 12. Binary sensitivity thresholds
###############################################################################

cnv_positive_95th <- handoff$CNV_score >= threshold_95
cnv_positive_99th <- handoff$CNV_score >= threshold_99

n_positive_95th <- sum(cnv_positive_95th)
n_positive_99th <- sum(cnv_positive_99th)

if (n_positive_95th != 1634L) {
  stop(
    "Expected 1,634 CNV-positive cells at the 95th percentile; observed ",
    n_positive_95th
  )
}

if (n_positive_99th != 1482L) {
  stop(
    "Expected 1,482 CNV-positive cells at the 99th percentile; observed ",
    n_positive_99th
  )
}

intermediate_count <- sum(
  cnv_positive_95th & !cnv_positive_99th
)

if (intermediate_count != 152L) {
  stop(
    "Expected 152 cells between the 95th and <99th percentile; observed ",
    intermediate_count
  )
}

###############################################################################
# 13. CNV-positive counts by original Cell_subtype
###############################################################################

expected_positive_by_group <- data.frame(
  group = c(
    "Malignant cells",
    "tS1",
    "tS2",
    "tS3",
    "Reference"
  ),
  CNV_positive_99th = c(
    923L,
    213L,
    285L,
    56L,
    5L
  ),
  stringsAsFactors = FALSE
)

observed_positive_by_group <- data.frame(
  group = names(
    table(
      group[cnv_positive_99th]
    )
  ),
  CNV_positive_99th = as.integer(
    table(
      group[cnv_positive_99th]
    )
  ),
  stringsAsFactors = FALSE
)

merged_group_check <- merge(
  expected_positive_by_group,
  observed_positive_by_group,
  by = "group",
  all.x = TRUE,
  suffixes = c("_expected", "_observed")
)

merged_group_check$CNV_positive_99th_observed[
  is.na(merged_group_check$CNV_positive_99th_observed)
] <- 0L

if (any(
  merged_group_check$CNV_positive_99th_expected !=
  merged_group_check$CNV_positive_99th_observed
)) {
  stop("CNV-positive counts by pilot group do not match canonical results.")
}

###############################################################################
# 14. Scientific scope
#
# These are report-level scope statements, not required columns in the
# canonical handoff CSV.
###############################################################################

CNV_analysis_scope <- "inferCNV pilot only"

malignancy_scope <- "inferCNV pilot only"

outside_pilot_classification <- "Not assigned"

if (CNV_analysis_scope != "inferCNV pilot only") {
  stop("Unexpected CNV analysis scope.")
}

if (malignancy_scope != "inferCNV pilot only") {
  stop("Unexpected malignancy scope.")
}

if (outside_pilot_classification != "Not assigned") {
  stop("Outside-pilot classification must remain unassigned.")
}

###############################################################################
# 15. Required downstream outputs
###############################################################################

required_outputs <- c(
  "Person2_Pilot_sampling_by_patient_sample_subtype.csv",
  "Person2_CNV_concordance_by_subtype.csv",
  "Person2_CNV_sensitivity_summary.csv",
  "Person2_CNV_burden_by_cell.csv",
  "Person2_CNV_positive_by_cell_subtype_99th.csv",
  "Person2_CNV_sensitivity_thresholds.csv"
)

missing_outputs <- required_outputs[
  !file.exists(
    file.path(person2_dir, required_outputs)
  )
]

if (length(missing_outputs) > 0) {
  
  stop(
    "Missing required final output file(s):\n",
    paste(missing_outputs, collapse = "\n")
  )
}

###############################################################################
# 16. Final report
###############################################################################

cat("\n")
cat("========================================\n")
cat("PERSON 2 — FINAL PILOT QC: PASS\n")
cat("========================================\n")
cat("Pilot cells:                    2,420\n")
cat("Malignant supported (stringent): 889\n")
cat("Malignant supported (expanded):  940\n")
cat("Non-malignant:                   479\n")
cat("Uncertain (stringent):         1,052\n")
cat("Uncertain (expanded):          1,001\n")
cat("----------------------------------------\n")
cat("CNV-negative:                    786\n")
cat("CNV-uncertain:                   152\n")
cat("CNV-positive @99th:            1,482\n")
cat("CNV-positive @95th:            1,634\n")
cat("----------------------------------------\n")
cat("CNV analysis scope: ", CNV_analysis_scope, "\n", sep = "")
cat("Malignancy scope:   ", malignancy_scope, "\n", sep = "")
cat("Outside pilot:      ", outside_pilot_classification, "\n", sep = "")
cat("----------------------------------------\n")
cat("Full 31,136-cell inferCNV rerun: NO\n")
cat("========================================\n")
cat("All final QC checks passed.\n")
cat("========================================\n\n")

