###############################################################################
# 06_integrate_cnv_epithelial_annotation_doublets.R
#
# Purpose:
#   Combine CNV evidence with original annotation, epithelial identity, and
#   doublet information. No single marker is allowed to define malignancy.
#
# Primary conservative rule used in the completed Pilot:
#   original Malignant annotation + CNV-positive at 99th percentile +
#   singlet status -> Malignant supported
#
# Reference cells -> Non-malignant
# Everything else -> Uncertain
#
# This preserves biological uncertainty instead of forcing a binary call.
###############################################################################

project_root <- Sys.getenv("CTA_PROJECT_ROOT", unset = "D:/CTA")
person2_dir <- file.path(project_root, "person 2")

handoff_file <- file.path(
  person2_dir,
  "Person2_inferCNV_pilot_sensitivity_handoff.csv"
)

if (!file.exists(handoff_file)) {
  stop("Completed Pilot handoff is missing: ", handoff_file)
}

x <- read.csv(
  handoff_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required <- c(
  "cell_id", "Patient_ID", "Sample", "Cell_subtype",
  "CNV_score", "CNV_label", "final_malignancy_class"
)

missing <- setdiff(required, names(x))

if (length(missing) > 0) {
  stop("Handoff is missing required columns: ", paste(missing, collapse = ", "))
}

if (nrow(x) != 2420L) {
  stop("Pilot handoff must contain 2,420 cells.")
}

if (anyDuplicated(x$cell_id)) {
  stop("Pilot handoff contains duplicate cell IDs.")
}

cat("\nIntegrated Pilot classification summary:\n")
print(table(x$final_malignancy_class, useNA = "ifany"))

cat("\nThe 889 Malignant supported cells are Pilot-level results only.\n")
cat("No CNV class is assigned outside the 2,420-cell Pilot.\n")
