# Person 2 — 05_validate_pilot_cnv_results.R
#
# Purpose:
# Validate the completed 2,420-cell inferCNV Pilot and document
# the recorded CNV-based sensitivity analysis.
#
# IMPORTANT:
# This script does NOT rerun inferCNV.
# It reads the completed Pilot handoff generated from the
# existing inferCNV analysis.
#
# The Pilot represents a CNV-based sensitivity analysis.
# It is NOT a CNV classification of all 31,136 malignant-related cells.
# =========================================================================
# 1. PROJECT PATHS
# =========================================================================

project_root <- Sys.getenv(
  "CTA_PROJECT_ROOT",
  unset = "D:/CTA"
)

person2_dir <- file.path(
  project_root,
  "person 2"
)

handoff_file <- file.path(
  person2_dir,
  "Person2_inferCNV_pilot_sensitivity_handoff.csv"
)

qc_file <- file.path(
  person2_dir,
  "Person2_Pilot_sensitivity_QC_summary.csv"
)


# =========================================================================
# 2. LOAD COMPLETED PILOT HANDOFF
# =========================================================================

if (!file.exists(handoff_file)) {
  
  stop(
    "Completed Pilot handoff was not found:\n",
    handoff_file
  )
  
}

handoff <- read.csv(
  handoff_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


# =========================================================================
# 3. CHECK REQUIRED COLUMNS
# =========================================================================

required_columns <- c(
  "cell_id",
  "Patient_ID",
  "Sample",
  "Cell_subtype",
  "Cell_type",
  "doublet_score",
  "doublet_class",
  "CNV_score",
  "CNV_label",
  "final_malignancy_class",
  "malignancy_stringent",
  "malignancy_expanded",
  "CNV_analysis_scope",
  "malignancy_scope",
  "outside_pilot_classification"
)

missing_columns <- setdiff(
  required_columns,
  names(handoff)
)

if (length(missing_columns) > 0L) {
  
  stop(
    "Pilot handoff is missing required columns: ",
    paste(
      missing_columns,
      collapse = ", "
    )
  )
  
}


# =========================================================================
# 4. VALIDATE PILOT SIZE
# =========================================================================

if (nrow(handoff) != 2420L) {
  
  stop(
    "Pilot handoff must contain exactly 2,420 cells. ",
    "Found: ",
    nrow(handoff)
  )
  
}


# =========================================================================
# 5. VALIDATE CELL IDS
# =========================================================================

if (anyNA(handoff$cell_id)) {
  
  stop(
    "Pilot handoff contains missing cell IDs."
  )
  
}

if (anyDuplicated(handoff$cell_id)) {
  
  stop(
    "Pilot handoff contains duplicated cell IDs."
  )
  
}


# =========================================================================
# 6. VALIDATE CNV SCORES
# =========================================================================

if (!is.numeric(handoff$CNV_score)) {
  
  stop(
    "CNV_score must be numeric."
  )
  
}

if (anyNA(handoff$CNV_score)) {
  
  stop(
    "Pilot handoff contains missing CNV scores."
  )
  
}


# =========================================================================
# 7. VALIDATE PILOT ANALYSIS SCOPE
# =========================================================================
#
# Every row in this table belongs to the completed 2,420-cell Pilot.
# The scope must therefore explicitly identify the analysis as Pilot-only.


if (
  any(
    handoff$CNV_analysis_scope !=
    "inferCNV pilot only"
  )
) {
  
  stop(
    "Unexpected CNV_analysis_scope detected."
  )
  
}


# =========================================================================
# 8. VALIDATE OUTSIDE-PILOT HANDLING
# =========================================================================
#
# Cells outside the Pilot must not receive a CNV classification.
# This is a project-level limitation and is preserved explicitly.


if (
  any(
    handoff$outside_pilot_classification !=
    "Not assigned"
  )
) {
  
  stop(
    "Cells outside the Pilot must remain unassigned."
  )
  
}


# =========================================================================
# 9. VALIDATE PILOT COMPOSITION
# =========================================================================
#
# The observation portion of the canonical Pilot contains:
#
#   Malignant cells = 1,050
#   tS1             =   461
#   tS2             =   366
#   tS3             =    64
#
# Total observation cells = 1,941
#
# The remaining 479 cells are the Pilot reference cells.
#
# Reference cells are not assumed to appear as "Reference" in the
# Cell_subtype column of the final handoff.


subtype_counts <- table(
  handoff$Cell_subtype,
  useNA = "ifany"
)

cat("\nPilot Cell_subtype counts:\n")
print(subtype_counts)


expected_subtypes <- c(
  "Malignant cells" = 1050L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)


for (subtype_name in names(expected_subtypes)) {
  
  observed <- sum(
    handoff$Cell_subtype == subtype_name,
    na.rm = TRUE
  )
  
  if (
    is.na(observed) ||
    observed != expected_subtypes[subtype_name]
  ) {
    
    stop(
      "Unexpected Pilot count for '",
      subtype_name,
      "': expected ",
      expected_subtypes[subtype_name],
      ", found ",
      observed,
      "."
    )
    
  }
  
}


# =========================================================================
# 10. VALIDATE OBSERVATION AND REFERENCE COUNTS
# =========================================================================

observation_count <- sum(
  handoff$Cell_subtype %in%
    names(expected_subtypes),
  na.rm = TRUE
)


if (
  is.na(observation_count) ||
  observation_count != 1941L
) {
  
  stop(
    "Expected 1,941 observation cells; found ",
    observation_count,
    "."
  )
  
}


reference_count <- 2420L - observation_count


if (
  is.na(reference_count) ||
  reference_count != 479L
) {
  
  stop(
    "Expected 479 Reference cells; found ",
    reference_count,
    "."
  )
  
}


cat(
  "\nObservation cells validated: ",
  observation_count,
  "\n",
  sep = ""
)

cat(
  "Reference cells validated: ",
  reference_count,
  "\n",
  sep = ""
)


# =========================================================================
# 11. VALIDATE MALIGNANT SUPPORTED COUNT
# =========================================================================
#
# The canonical Pilot contains 889 cells classified as
# Malignant supported within the Pilot analysis.


supported_count <- sum(
  handoff$final_malignancy_class ==
    "Malignant supported",
  na.rm = TRUE
)


if (
  is.na(supported_count) ||
  supported_count != 889L
) {
  
  stop(
    "Expected 889 Malignant supported cells; found ",
    supported_count,
    "."
  )
  
}


# =========================================================================
# 12. READ RECORDED SENSITIVITY THRESHOLDS
# =========================================================================
#
# The QC summary is treated as the recorded source of truth for
# the completed Pilot sensitivity analysis.
#
# The script does NOT impose or recalculate historical cutoff values.


if (!file.exists(qc_file)) {
  
  stop(
    "Pilot QC summary is required to validate the recorded ",
    "sensitivity thresholds:\n",
    qc_file
  )
  
}


qc <- read.csv(
  qc_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


if (
  !all(
    c("metric", "value") %in%
    names(qc)
  )
) {
  
  stop(
    "Pilot QC summary must contain 'metric' and 'value' columns."
  )
  
}


cutoff_95 <- qc$value[
  qc$metric == "95th percentile cutoff"
]

cutoff_99 <- qc$value[
  qc$metric == "99th percentile cutoff"
]


if (length(cutoff_95) != 1L) {
  
  stop(
    "Could not identify exactly one 95th percentile cutoff ",
    "in the Pilot QC summary."
  )
  
}


if (length(cutoff_99) != 1L) {
  
  stop(
    "Could not identify exactly one 99th percentile cutoff ",
    "in the Pilot QC summary."
  )
  
}


cutoff_95 <- suppressWarnings(
  as.numeric(cutoff_95)
)

cutoff_99 <- suppressWarnings(
  as.numeric(cutoff_99)
)


if (
  is.na(cutoff_95) ||
  is.na(cutoff_99)
) {
  
  stop(
    "Recorded sensitivity thresholds contain missing or ",
    "non-numeric values."
  )
  
}


cat("\nRecorded Pilot sensitivity thresholds:\n")

cat(
  "95th percentile: ",
  cutoff_95,
  "\n",
  sep = ""
)

cat(
  "99th percentile: ",
  cutoff_99,
  "\n",
  sep = ""
)


# =========================================================================
# 13. BUILD VALIDATION SUMMARY
# =========================================================================

validation_summary <- data.frame(
  metric = c(
    "Pilot cells",
    "Observation cells",
    "Reference cells",
    "Malignant pilot cells",
    "tS1 pilot cells",
    "tS2 pilot cells",
    "tS3 pilot cells",
    "Malignant supported",
    "95th percentile cutoff",
    "99th percentile cutoff",
    "Full malignant-related object cells",
    "CNV classification outside Pilot"
  ),
  value = c(
    2420L,
    1941L,
    479L,
    1050L,
    461L,
    366L,
    64L,
    889L,
    cutoff_95,
    cutoff_99,
    31136L,
    "Not assigned"
  ),
  stringsAsFactors = FALSE
)


# =========================================================================
# 14. SAVE VALIDATION SUMMARY
# =========================================================================

output_file <- file.path(
  person2_dir,
  "Person2_Pilot_CNV_validation_summary.csv"
)


write.csv(
  validation_summary,
  output_file,
  row.names = FALSE,
  quote = TRUE
)


# =========================================================================
# 15. FINAL REPORT
# =========================================================================

cat("\n")
cat("========================================\n")
cat("PERSON 2 — PILOT CNV VALIDATION\n")
cat("========================================\n")

cat(
  "Pilot cells: 2,420\n"
)

cat(
  "Observation cells: 1,941\n"
)

cat(
  "Reference cells: 479\n"
)

cat(
  "Malignant pilot cells: 1,050\n"
)

cat(
  "tS1 pilot cells: 461\n"
)

cat(
  "tS2 pilot cells: 366\n"
)

cat(
  "tS3 pilot cells: 64\n"
)

cat(
  "Malignant supported: 889\n"
)

cat(
  "95th percentile cutoff: ",
  cutoff_95,
  "\n",
  sep = ""
)

cat(
  "99th percentile cutoff: ",
  cutoff_99,
  "\n",
  sep = ""
)

cat(
  "Full malignant-related object: 31,136 cells\n"
)

cat(
  "CNV classification outside Pilot: NOT ASSIGNED\n"
)

cat(
  "inferCNV rerun: NO\n"
)

cat(
  "Validation summary:\n",
  output_file,
  "\n",
  sep = ""
)

cat(
  "Status: PASS\n"
)

cat("========================================\n")