# Person 2 — 04_run_infercnv_pilot.R
#
# Purpose:
# Document and control the canonical inferCNV Pilot analysis.
#
# The Pilot contains 2,420 frozen cells and is used as a
# CNV-based sensitivity analysis.
#
# IMPORTANT:
# The historical Pilot has already been generated and analyzed.
# Therefore, this script does NOT rerun inferCNV by default.
#
# A rerun is intentionally disabled unless:
#
#   Sys.setenv(CTA_RERUN_PILOT = "TRUE")
#
# is explicitly set before running the script.
#
# The frozen Pilot cell IDs remain the reproducibility
# source of truth because the historical random seed
# could not be recovered from the saved artifacts.
# -------------------------------------------------------------------------
# 1. Project paths
# -------------------------------------------------------------------------

project_root <- Sys.getenv(
  "CTA_PROJECT_ROOT",
  unset = "D:/CTA"
)

person2_dir <- file.path(
  project_root,
  "person 2"
)

pilot_file <- file.path(
  person2_dir,
  "20_infercnv_annotations_pilot_2420_used.txt"
)

counts_file <- file.path(
  person2_dir,
  "15_infercnv_counts_19532_genes.rds"
)

gene_order_file <- file.path(
  person2_dir,
  "18_infercnv_gene_order_clean.txt"
)

output_dir <- file.path(
  person2_dir,
  "inferCNV_Pilot"
)


# -------------------------------------------------------------------------
# 2. Check the frozen Pilot
# -------------------------------------------------------------------------

if (!file.exists(pilot_file)) {
  stop(
    "Frozen Pilot annotation file was not found:\n",
    pilot_file
  )
}

pilot <- read.delim(
  pilot_file,
  header = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)


# -------------------------------------------------------------------------
# 3. Check Pilot structure
# -------------------------------------------------------------------------

required_columns <- c(
  "cell_id",
  "cell_group"
)

missing_columns <- setdiff(
  required_columns,
  colnames(pilot)
)

if (length(missing_columns) > 0L) {
  stop(
    "Pilot annotation is missing required columns: ",
    paste(missing_columns, collapse = ", ")
  )
}


# -------------------------------------------------------------------------
# 4. Confirm the canonical Pilot size
# -------------------------------------------------------------------------

if (nrow(pilot) != 2420L) {
  stop(
    "Canonical Pilot must contain exactly 2,420 cells. ",
    "Found: ",
    nrow(pilot)
  )
}


# -------------------------------------------------------------------------
# 5. Check cell IDs
# -------------------------------------------------------------------------

if (anyNA(pilot$cell_id)) {
  stop("Pilot contains missing cell IDs.")
}

if (anyDuplicated(pilot$cell_id)) {
  stop("Pilot contains duplicated cell IDs.")
}


# -------------------------------------------------------------------------
# 6. Confirm the canonical Pilot composition
# -------------------------------------------------------------------------
#
# The frozen Pilot uses the following canonical groups:
#
#   Malignant cells = 1050
#   Reference       = 479
#   tS1             = 461
#   tS2             = 366
#   tS3             = 64
#
# The three reference source categories used during Pilot construction
# are not renamed here. The final frozen Pilot intentionally stores
# them under the single canonical group "Reference".
#
# This prevents the GitHub pipeline from silently changing the
# composition of the already analyzed Pilot.


expected_counts <- c(
  "Malignant cells" = 1050L,
  "Reference"       = 479L,
  "tS1"             = 461L,
  "tS2"             = 366L,
  "tS3"             = 64L
)

observed_counts <- table(pilot$cell_group)


missing_groups <- setdiff(
  names(expected_counts),
  names(observed_counts)
)

if (length(missing_groups) > 0L) {
  stop(
    "Canonical Pilot is missing expected group(s): ",
    paste(missing_groups, collapse = ", ")
  )
}


for (group_name in names(expected_counts)) {
  
  observed_value <- unname(
    observed_counts[group_name]
  )
  
  expected_value <- expected_counts[group_name]
  
  if (observed_value != expected_value) {
    
    stop(
      "Pilot composition mismatch for '",
      group_name,
      "': expected ",
      expected_value,
      ", found ",
      observed_value,
      "."
    )
  }
}


if (sum(observed_counts) != 2420L) {
  stop(
    "Canonical Pilot group counts do not sum to 2,420 cells."
  )
}


# -------------------------------------------------------------------------
# 7. Define the canonical inferCNV settings
# -------------------------------------------------------------------------
#
# These settings document the Pilot analysis that was already performed.
#
# They are recorded here for reproducibility and GitHub documentation.
#
# They do not trigger a new inferCNV run.


infercnv_settings <- list(
  
  cutoff = 0.1,
  
  cluster_by_groups = TRUE,
  
  denoise = TRUE,
  
  HMM = FALSE,
  
  num_threads = 1,
  
  analysis_mode = "samples",
  
  input_genes = 19532L,
  
  pilot_cells = 2420L,
  
  full_malignant_related_cells = 31136L
)


# -------------------------------------------------------------------------
# 8. Create the output directory
# -------------------------------------------------------------------------

if (!dir.exists(output_dir)) {
  
  dir.create(
    output_dir,
    recursive = TRUE,
    showWarnings = FALSE
  )
}


# -------------------------------------------------------------------------
# 9. Save the validated Pilot composition
# -------------------------------------------------------------------------

composition <- data.frame(
  cell_group = names(observed_counts),
  pilot_cells = as.integer(observed_counts),
  stringsAsFactors = FALSE
)

composition_file <- file.path(
  output_dir,
  "Pilot_composition.csv"
)

write.csv(
  composition,
  composition_file,
  row.names = FALSE,
  quote = TRUE
)


# -------------------------------------------------------------------------
# 10. Save the inferCNV settings
# -------------------------------------------------------------------------

settings_table <- data.frame(
  setting = names(infercnv_settings),
  value = vapply(
    infercnv_settings,
    function(x) paste(x, collapse = ", "),
    character(1)
  ),
  stringsAsFactors = FALSE
)

settings_file <- file.path(
  output_dir,
  "inferCNV_Pilot_settings.csv"
)

write.csv(
  settings_table,
  settings_file,
  row.names = FALSE,
  quote = TRUE
)


# -------------------------------------------------------------------------
# 11. Save the provenance record
# -------------------------------------------------------------------------

provenance_file <- file.path(
  output_dir,
  "inferCNV_Pilot_provenance.txt"
)

sink(provenance_file)

cat("Person 2 — inferCNV Pilot Provenance\n")
cat("====================================\n\n")

cat("Project root:\n")
cat(project_root, "\n\n")

cat("Frozen Pilot:\n")
cat("2,420 cells\n\n")

cat("Full malignant-related dataset:\n")
cat("31,136 cells\n\n")

cat("Analysis purpose:\n")
cat("CNV-based sensitivity analysis\n\n")

cat("Historical random seed:\n")
cat(
  "Not recoverable from the saved artifacts.\n\n"
)

cat(
  "Frozen Pilot cell IDs are the reproducibility source of truth.\n\n"
)

cat("inferCNV settings:\n")
print(infercnv_settings)

cat("\nCNV assignment outside the Pilot:\n")
cat("Not assigned\n")

cat("\nFull 31,136-cell inferCNV rerun:\n")
cat("Not performed\n")

sink()


# -------------------------------------------------------------------------
# 12. Check whether an explicit rerun was requested
# -------------------------------------------------------------------------
#
# Normally this is FALSE.
#
# Do NOT set CTA_RERUN_PILOT to TRUE during the normal GitHub workflow.
#
# The existing Pilot is the canonical analysis.


rerun_pilot <- identical(
  toupper(
    Sys.getenv(
      "CTA_RERUN_PILOT",
      unset = "FALSE"
    )
  ),
  "TRUE"
)


# -------------------------------------------------------------------------
# 13. Controlled rerun path
# -------------------------------------------------------------------------
#
# This section is intentionally inactive during normal execution.
# It only checks the large inferCNV inputs if a rerun was explicitly
# requested by the analyst.
#
# The canonical Pilot is NOT replaced automatically.


if (rerun_pilot) {
  
  cat("\n")
  cat("Explicit Pilot rerun requested.\n")
  
  if (!file.exists(counts_file)) {
    
    stop(
      "inferCNV count matrix was not found:\n",
      counts_file
    )
  }
  
  if (!file.exists(gene_order_file)) {
    
    stop(
      "inferCNV gene-order file was not found:\n",
      gene_order_file
    )
  }
  
  if (!requireNamespace(
    "infercnv",
    quietly = TRUE
  )) {
    
    stop(
      "Package 'infercnv' is required for an explicit rerun."
    )
  }
  
  cat(
    "The large count matrix will only be loaded because\n",
    "an explicit rerun was requested.\n",
    sep = ""
  )
  
  infercnv_counts <- readRDS(
    counts_file
  )
  
  expected_dimensions <- c(
    19532L,
    31136L
  )
  
  if (!identical(
    dim(infercnv_counts),
    expected_dimensions
  )) {
    
    stop(
      "Unexpected count matrix dimensions. ",
      "Expected 19,532 × 31,136."
    )
  }
  
  cat(
    "Count matrix dimensions confirmed: ",
    paste(
      dim(infercnv_counts),
      collapse = " × "
    ),
    "\n",
    sep = ""
  )
  
  cat(
    "\nThe canonical Pilot will not be overwritten automatically.\n"
  )
  
} else {
  
  cat("\n")
  cat("No inferCNV rerun requested.\n")
  cat(
    "The existing 2,420-cell Pilot remains the canonical analysis.\n"
  )
}


# -------------------------------------------------------------------------
# 14. Final report
# -------------------------------------------------------------------------

cat("\n")
cat("========================================\n")
cat("PERSON 2 — INFERCNV PILOT\n")
cat("========================================\n")

cat(
  "Canonical Pilot: 2,420 cells\n"
)

cat(
  "Malignant cells in Pilot: ",
  expected_counts["Malignant cells"],
  "\n",
  sep = ""
)

cat(
  "tS1 cells in Pilot: ",
  expected_counts["tS1"],
  "\n",
  sep = ""
)

cat(
  "tS2 cells in Pilot: ",
  expected_counts["tS2"],
  "\n",
  sep = ""
)

cat(
  "tS3 cells in Pilot: ",
  expected_counts["tS3"],
  "\n",
  sep = ""
)

cat(
  "Reference cells in Pilot: ",
  expected_counts["Reference"],
  "\n",
  sep = ""
)

cat(
  "Full malignant-related dataset: 31,136 cells\n"
)

cat(
  "CNV outside Pilot: NOT ASSIGNED\n"
)

cat(
  "Historical random seed: NOT RECOVERABLE\n"
)

cat(
  "InferCNV rerun requested: ",
  ifelse(
    rerun_pilot,
    "YES",
    "NO"
  ),
  "\n",
  sep = ""
)

cat(
  "Status: PASS\n"
)

cat("========================================\n")