# Inputs and provenance

## Person 1 / Person 4 base tables

- `person4_review/package/GSE131907_CTA_sample_metrics.csv`
- `person4_review/package/GSE131907_CTA_sample_state_metrics.csv`
- `person4_review/package/GSE131907_pseudobulk_design.csv`
- `person4_review/package/GSE131907_pseudobulk_counts_by_sample_state.tsv.gz`
- `person4_review/package/GSE131907_sample_to_patient_mapping.csv`

## Person 2 inferCNV sensitivity

- `upload/Person2_inferCNV_pilot_sensitivity_handoff.csv`
- `upload/30_Person3_final_scores_handoff.csv` (889 cell identifiers matching the supported set)
- `upload/42_patient_level_inferCNV_QC.csv`

The QC table lists P0006 as missing, but the P0006 final inferCNV object and both heatmaps were supplied. Therefore this row is treated as stale documentation, not as proof that the run is absent.

## Person 3 state scores

- `upload/GSE131907_Person3_AllCells_Scores_Handoff (1).csv`
- `upload/30_Person3_final_scores_handoff.csv`

The full score handoff contained missing Patient IDs in 29,195 rows. These were deterministically repaired from the authoritative Sample-to-Patient mapping. The resulting file is `results/GSE131907_AllCells_Scores_with_PatientID.csv` with zero missing patient IDs.

## Reproducibility decisions

- Seed: 131907.
- Inference unit: patient/sample.
- Full 31,136 malignant-cell set: primary analysis.
- CNV-supported 889-cell set: sensitivity analysis only.
- Multiple testing: Benjamini–Hochberg FDR.
- Mixed `tL/B` samples excluded from the primary-versus-metastasis contrast.
