#!/usr/bin/env python3
"""Reproducible Person 4 analysis for GSE131907.

Uses patient/sample as the inferential unit. CNV-supported 889 cells are a
sensitivity subset only. The script writes CSV results and publication-ready
figures without converting the full expression matrix to dense format.
"""
from pathlib import Path
import json, shutil, warnings
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns

SEED = 131907
rng = np.random.default_rng(SEED)
ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT / "person4_review" / "package"
UP = ROOT / "upload"
OUT = ROOT / "person4_final"
RES = OUT / "results"
FIG = OUT / "figures"
RES.mkdir(parents=True, exist_ok=True); FIG.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid", context="talk")

def bh(p):
    p=np.asarray(p,float); n=len(p); order=np.argsort(p); out=np.empty(n); q=1.
    for rank, idx in reversed(list(enumerate(order, start=1))):
        q=min(q,p[idx]*n/rank); out[idx]=q
    return np.clip(out,0,1)

def cliffs_delta(x,y):
    x=np.asarray(x); y=np.asarray(y)
    return float((np.sum(x[:,None]>y)-np.sum(x[:,None]<y))/(len(x)*len(y)))

def boot_spearman(x,y,B=3000):
    x=np.asarray(x,float); y=np.asarray(y,float); n=len(x); vals=[]
    for _ in range(B):
        ix=rng.integers(0,n,n)
        if len(np.unique(x[ix]))>1 and len(np.unique(y[ix]))>1:
            vals.append(stats.spearmanr(x[ix],y[ix]).statistic)
    return tuple(np.nanpercentile(vals,[2.5,97.5])) if vals else (np.nan,np.nan)

# Repair full score handoff with authoritative sample-to-patient mapping.
scores=pd.read_csv(UP/"GSE131907_Person3_AllCells_Scores_Handoff (1).csv")
mapping=pd.read_csv(PKG/"GSE131907_sample_to_patient_mapping.csv")
mp=mapping.set_index("Sample")["Patient_id"].to_dict()
scores["Patient_ID_original"]=scores["Patient_ID"]
scores["Patient_ID"]=scores["Sample"].map(mp)
assert scores["Patient_ID"].notna().all() and scores["cell_id"].is_unique
scores.to_csv(RES/"GSE131907_AllCells_Scores_with_PatientID.csv",index=False)

score_cols=["EMT_Score","Stemness_Score","Plasticity_Score","Proliferation_Score","Lung_Diff_Score"]
sample_scores=(scores.groupby(["Patient_ID","Sample","Sample_Origin"],as_index=False)[score_cols]
               .median())
sample_scores["n_cells"]=scores.groupby(["Patient_ID","Sample","Sample_Origin"]).size().values
sample_scores.to_csv(RES/"GSE131907_Sample_Score_Summary.csv",index=False)
state_scores=(scores.groupby(["Patient_ID","Sample","Sample_Origin","original_Cell_subtype"],as_index=False)
              .agg(**{c:(c,"median") for c in score_cols}, n_cells=("cell_id","size")))
state_scores.to_csv(RES/"GSE131907_Sample_State_Score_Summary.csv",index=False)

cta=pd.read_csv(PKG/"GSE131907_CTA_sample_metrics.csv")
cta_state=pd.read_csv(PKG/"GSE131907_CTA_sample_state_metrics.csv")
cta["log2CPM"]=np.log2(cta["CPM"]+0.5); cta["detected_sample"]=cta["raw_count"]>0
genes=sorted(cta.gene.unique())

# Paired primary tS2 vs tS1 (within patient/sample; >=20 cells per state).
eligible=cta_state[cta_state["n_cells"]>=20].copy(); eligible["log2CPM"]=np.log2(eligible.CPM+0.5)
rows=[]
for g in genes:
    d=eligible[(eligible.gene==g)&(eligible.Sample_Origin=="tLung")&eligible.Cell_subtype.isin(["tS1","tS2"])]
    w=d.pivot_table(index=["Patient_id","Sample"],columns="Cell_subtype",values="log2CPM",aggfunc="first").dropna()
    delta=w.tS2-w.tS1
    try: p=stats.wilcoxon(delta,zero_method="wilcox",alternative="two-sided").pvalue if np.any(delta!=0) else 1.
    except ValueError: p=1.
    rows.append(dict(gene=g,n_pairs=len(w),median_log2CPM_tS1=w.tS1.median(),median_log2CPM_tS2=w.tS2.median(),
                     median_paired_delta_tS2_minus_tS1=delta.median(),wilcoxon_p=p,
                     pairs_tS1_detected=int((w.tS1>np.log2(.5)).sum()),pairs_tS2_detected=int((w.tS2>np.log2(.5)).sum())))
paired=pd.DataFrame(rows); paired["FDR_BH"]=bh(paired.wilcoxon_p); paired.to_csv(RES/"CTA_Paired_tS2_vs_tS1.csv",index=False)

# Exploratory metastasis vs primary: exclude tL/B because mixed tissue label.
site=cta[cta.Sample_Origin.isin(["tLung","mLN","mBrain"])].copy()
site["group"]=np.where(site.Sample_Origin=="tLung","Primary","Metastasis")
rows=[]
for g in genes:
    d=site[site.gene==g]; a=d[d.group=="Metastasis"]; b=d[d.group=="Primary"]
    table=[[int(a.detected_sample.sum()),int((~a.detected_sample).sum())],[int(b.detected_sample.sum()),int((~b.detected_sample).sum())]]
    fp=stats.fisher_exact(table).pvalue
    mw=stats.mannwhitneyu(a.log2CPM,b.log2CPM,alternative="two-sided").pvalue
    rows.append(dict(gene=g,n_metastasis=len(a),n_primary=len(b),detected_metastasis=int(a.detected_sample.sum()),detected_primary=int(b.detected_sample.sum()),
        prevalence_metastasis=a.detected_sample.mean(),prevalence_primary=b.detected_sample.mean(),prevalence_delta=a.detected_sample.mean()-b.detected_sample.mean(),
        median_log2CPM_metastasis=a.log2CPM.median(),median_log2CPM_primary=b.log2CPM.median(),median_log2CPM_delta=a.log2CPM.median()-b.log2CPM.median(),
        cliffs_delta=cliffs_delta(a.log2CPM.values,b.log2CPM.values),fisher_p=fp,mannwhitney_p=mw))
site_res=pd.DataFrame(rows); site_res["fisher_FDR_BH"]=bh(site_res.fisher_p); site_res["mannwhitney_FDR_BH"]=bh(site_res.mannwhitney_p)
site_res.to_csv(RES/"CTA_Exploratory_Metastasis_vs_Primary.csv",index=False)

# Sample-level CTA-expression / cell-state score associations (n=32).
joined=cta.merge(sample_scores,on=["Sample","Sample_Origin"],how="inner")
rows=[]
for g in genes:
    d=joined[joined.gene==g]
    for s in score_cols:
        rho,p=stats.spearmanr(d.log2CPM,d[s]); lo,hi=boot_spearman(d.log2CPM.values,d[s].values)
        rows.append(dict(gene=g,score=s,n_samples=len(d),spearman_rho=rho,p_value=p,bootstrap_CI_low=lo,bootstrap_CI_high=hi))
assoc=pd.DataFrame(rows); assoc["FDR_BH_global"]=bh(assoc.p_value); assoc.to_csv(RES/"CTA_Sample_Score_Associations.csv",index=False)

# CNV-supported subset sensitivity: same scores computed once in full object.
supported=pd.read_csv(UP/"30_Person3_final_scores_handoff.csv",usecols=["cell_id"])
sub=scores[scores.cell_id.isin(set(supported.cell_id))]
assert len(sub)==889
full_pat=scores.groupby("Patient_ID")[score_cols].median(); sub_pat=sub.groupby("Patient_ID")[score_cols].median()
common=full_pat.index.intersection(sub_pat.index)
sens=[]
for pat in common:
    for s in score_cols:
        sens.append(dict(Patient_ID=pat,score=s,full_median=full_pat.loc[pat,s],CNV889_median=sub_pat.loc[pat,s],delta_CNV889_minus_full=sub_pat.loc[pat,s]-full_pat.loc[pat,s]))
sens=pd.DataFrame(sens); sens.to_csv(RES/"CNV889_Patient_Sensitivity.csv",index=False)
sens_sum=sens.groupby("score").agg(n_patients=("Patient_ID","nunique"),median_delta=("delta_CNV889_minus_full","median"),
 q1_delta=("delta_CNV889_minus_full",lambda x:x.quantile(.25)),q3_delta=("delta_CNV889_minus_full",lambda x:x.quantile(.75)),
 max_abs_delta=("delta_CNV889_minus_full",lambda x:np.max(np.abs(x)))).reset_index()
sens_sum.to_csv(RES/"CNV889_Sensitivity_Summary.csv",index=False)

# Transparent exploratory ranking. Rank-normalized criteria, no claim of validation.
rank=site_res[["gene","prevalence_delta","median_log2CPM_delta","prevalence_metastasis"]].copy()
prog=[]
for g in genes:
    q=assoc[assoc.gene==g].set_index("score").spearman_rho
    prog.append(max(0,q.get("EMT_Score",0),q.get("Plasticity_Score",0),q.get("Proliferation_Score",0),-q.get("Lung_Diff_Score",0)))
rank["progression_program_score"]=prog
rank=rank.merge(paired[["gene","median_paired_delta_tS2_minus_tS1"]],on="gene")
crit=["prevalence_delta","median_log2CPM_delta","prevalence_metastasis","progression_program_score"]
rank["state_effect_abs"]=rank.median_paired_delta_tS2_minus_tS1.abs(); crit.append("state_effect_abs")
weights=dict(prevalence_delta=.30,median_log2CPM_delta=.25,prevalence_metastasis=.20,progression_program_score=.15,state_effect_abs=.10)
for c in crit:
    rank[c+"_scaled"]=rank[c].rank(pct=True,method="average")
rank["composite_score"]=sum(rank[c+"_scaled"]*weights[c] for c in crit)
rank=rank.sort_values("composite_score",ascending=False).reset_index(drop=True); rank.insert(0,"rank",np.arange(1,len(rank)+1))
rank["status"]="Exploratory shortlist; requires independent validation"
rank.to_csv(RES/"CTA_Ranking_Preliminary.csv",index=False)

# Audit table.
audit=pd.DataFrame([
 ["Full score rows",len(scores),31136,len(scores)==31136],
 ["Unique full cell IDs",scores.cell_id.nunique(),31136,scores.cell_id.is_unique],
 ["Missing Patient ID after repair",scores.Patient_ID.isna().sum(),0,scores.Patient_ID.notna().all()],
 ["Patients/samples",scores.Patient_ID.nunique(),32,scores.Patient_ID.nunique()==32],
 ["CNV-supported sensitivity cells",len(sub),889,len(sub)==889],
 ["Shared sensitivity patients",len(common),21,len(common)==21],
 ["CTA genes tested",len(genes),13,len(genes)==13],
],columns=["check","observed","expected","pass"])
audit.to_csv(RES/"Data_Audit.csv",index=False)

# Figures.
plt.figure(figsize=(10,6)); plot=site_res.sort_values("prevalence_delta")
plt.barh(plot.gene,plot.prevalence_delta,color=np.where(plot.prevalence_delta>0,"#2675A9","#A0A0A0")); plt.axvline(0,color="black",lw=1)
plt.xlabel("Metastasis minus primary detected-sample fraction"); plt.ylabel(""); plt.title("CTA prevalence difference by disease site")
plt.tight_layout(); plt.savefig(FIG/"Figure1_CTA_prevalence_difference.png",dpi=220); plt.close()

mat=assoc.pivot(index="gene",columns="score",values="spearman_rho").reindex(rank.gene)
plt.figure(figsize=(9,8)); sns.heatmap(mat,cmap="vlag",center=0,vmin=-.6,vmax=.6,annot=True,fmt=".2f",cbar_kws={"label":"Spearman rho"})
plt.title("Patient-level CTA and malignant-state score associations"); plt.xlabel(""); plt.ylabel(""); plt.tight_layout(); plt.savefig(FIG/"Figure2_CTA_state_association_heatmap.png",dpi=220); plt.close()

top=rank.head(5).gene.tolist(); d=site[site.gene.isin(top)].copy()
plt.figure(figsize=(11,6)); sns.boxplot(data=d,x="gene",y="log2CPM",hue="group",showfliers=False,palette=["#EE8A3B","#3572A5"]); sns.stripplot(data=d,x="gene",y="log2CPM",hue="group",dodge=True,color="black",size=3,alpha=.6)
handles,labels=plt.gca().get_legend_handles_labels(); plt.legend(handles[:2],labels[:2],title="",frameon=False); plt.ylabel("log2(CPM + 0.5)"); plt.xlabel(""); plt.title("Top exploratory CTA candidates by patient sample")
plt.tight_layout(); plt.savefig(FIG/"Figure3_Top_CTA_site_expression.png",dpi=220); plt.close()

plt.figure(figsize=(10,6)); sns.boxplot(data=sens,x="score",y="delta_CNV889_minus_full",color="#5B8DB8"); sns.stripplot(data=sens,x="score",y="delta_CNV889_minus_full",color="black",size=3,alpha=.55)
plt.axhline(0,color="black",lw=1); plt.xticks(rotation=25,ha="right"); plt.ylabel("Patient median difference"); plt.xlabel(""); plt.title("CNV-supported 889-cell sensitivity versus full malignant set")
plt.tight_layout(); plt.savefig(FIG/"Figure4_CNV889_sensitivity.png",dpi=220); plt.close()

plt.figure(figsize=(9,6)); rr=rank.sort_values("composite_score")
plt.barh(rr.gene,rr.composite_score,color=["#1F4E78" if x in rank.head(3).gene.tolist() else "#9AB6CE" for x in rr.gene]); plt.xlabel("Exploratory composite score"); plt.ylabel(""); plt.title("Preliminary CTA shortlist ranking")
plt.tight_layout(); plt.savefig(FIG/"Figure5_CTA_preliminary_ranking.png",dpi=220); plt.close()

summary={"seed":SEED,"n_cells":len(scores),"n_patients":scores.Patient_ID.nunique(),"n_cta":len(genes),"n_cnv_supported":len(sub),"top3":rank.head(3).gene.tolist(),
 "paired_significant_FDR_0_05":int((paired.FDR_BH<.05).sum()),"site_significant_FDR_0_05":int((site_res.mannwhitney_FDR_BH<.05).sum()),"association_significant_FDR_0_05":int((assoc.FDR_BH_global<.05).sum())}
(RES/"analysis_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
