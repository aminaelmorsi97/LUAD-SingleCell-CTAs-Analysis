import fs from "node:fs/promises";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const root = process.cwd();
const data = JSON.parse(await fs.readFile(`${root}/person4_final/workbook_data.json`, "utf8"));
const wb = Workbook.create();

function addSheet(name, rows, widths=[]) {
  const sh = wb.worksheets.add(name);
  sh.showGridLines = false;
  if (!rows.length) return sh;
  const nrows=rows.length, ncols=rows[0].length;
  const rg=sh.getRangeByIndexes(0,0,nrows,ncols); rg.values=rows;
  rg.format.font={name:"Arial",size:10,color:"#222222"};
  rg.format.verticalAlignment="center";
  const hdr=sh.getRangeByIndexes(0,0,1,ncols);
  hdr.format.fill="#1F4E78"; hdr.format.font={name:"Arial",size:10,bold:true,color:"#FFFFFF"};
  hdr.format.horizontalAlignment="center"; hdr.format.wrapText=true; hdr.format.rowHeight=30;
  rg.format.borders={preset:"all",style:"thin",color:"#D9D9D9"};
  for (let c=0;c<ncols;c++) sh.getRangeByIndexes(0,c,nrows,1).format.columnWidth=widths[c] || 16;
  if(nrows>1) sh.getRangeByIndexes(1,0,nrows-1,ncols).format.rowHeight=20;
  sh.freezePanes.freezeRows(1);
  return sh;
}

const sum=wb.worksheets.add("Summary"); sum.showGridLines=false; sum.tabColor="#1F4E78";
sum.getRange("A2:H2").merge(); sum.getRange("A2").values=[["GSE131907 Person 4 Final Results"]];
sum.getRange("A2:H2").format.font={name:"Arial",size:16,bold:true,color:"#000000"};
sum.getRange("A4:B10").values=[
 ["Metric","Result"],["Malignant cells",31136],["Patients / samples",32],["CTA genes tested",13],["CNV-supported sensitivity cells",889],["FDR-significant CTA tests",0],["Preliminary shortlist","PRAME, XAGE1B, XAGE1A"]
];
sum.getRange("A4:B4").format.fill="#1F4E78"; sum.getRange("A4:B4").format.font={bold:true,color:"#FFFFFF",name:"Arial",size:10};
sum.getRange("A4:B10").format.borders={preset:"all",style:"thin",color:"#D9D9D9"};
sum.getRange("A12:H12").values=[["Interpretation"]]; sum.getRange("A12:H12").merge(); sum.getRange("A12:H12").format.fill="#D9EAF7"; sum.getRange("A12").format.font={bold:true,color:"#000000"};
sum.getRange("A13:H16").merge(); sum.getRange("A13").values=[["No CTA comparison passed FDR 0.05. PRAME, XAGE1B and XAGE1A are exploratory candidates for independent validation, not validated metastatic biomarkers. Patient/sample is the inferential unit; the 889-cell inferCNV-supported set is used only for sensitivity analysis."]];
sum.getRange("A13:H16").format.wrapText=true; sum.getRange("A13:H16").format.verticalAlignment="top"; sum.getRange("A13:H16").format.font={name:"Arial",size:11,color:"#222222"};
sum.getRange("A1:H18").format.columnWidth=16; sum.getRange("A1").format.columnWidth=26; sum.getRange("B1").format.columnWidth=24;

addSheet("CTA Ranking",data.ranking,[8,14,18,20,20,22,22,18,18,18,18,18,18,18,42]);
addSheet("Metastasis vs Primary",data.site,[14,14,12,18,16,20,18,18,22,20,20,14,14,18,16,20]);
addSheet("tS2 vs tS1",data.paired,[14,12,20,20,24,14,18,18,14]);
addSheet("CTA State Associations",data.assoc,[14,24,14,18,14,18,18,18]);
addSheet("CNV Sensitivity",data.sensitivity,[24,14,18,18,18,18]);
addSheet("Audit",data.audit,[36,16,16,12]);

await wb.recalculate();
const inspect=await wb.inspect({kind:"sheet",include:"id,name",maxChars:3000});
console.log(inspect.ndjson || inspect);
const out=await SpreadsheetFile.exportXlsx(wb); await out.save(`${root}/person4_final/GSE131907_Person4_Final_Results.xlsx`);
const preview=await wb.render({sheetName:"Summary",autoCrop:"all",scale:1,format:"png"});
await fs.writeFile(`${root}/person4_final/excel_summary_preview.png`,new Uint8Array(await preview.arrayBuffer()));
