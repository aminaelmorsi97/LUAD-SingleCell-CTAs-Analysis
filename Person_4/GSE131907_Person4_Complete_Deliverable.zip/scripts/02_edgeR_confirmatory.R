#!/usr/bin/env Rscript
# Confirmatory pseudobulk model. The Python report contains complete CTA-level
# patient-unit tests; this script is supplied for journal-stage edgeR replication.
suppressPackageStartupMessages({library(edgeR); library(readr); library(dplyr); library(tidyr)})
root <- normalizePath(getwd())
counts <- read_tsv(file.path(root,"person4_review/package/GSE131907_pseudobulk_counts_by_sample_state.tsv.gz"), show_col_types=FALSE)
design <- read_csv(file.path(root,"person4_review/package/GSE131907_pseudobulk_design.csv"), show_col_types=FALSE)
# Paired tS2 vs tS1 in primary samples with >=20 cells in both states.
d <- design %>% filter(Sample_Origin=="tLung", Cell_subtype %in% c("tS1","tS2"), eligible_min_20_cells)
keep_samples <- d %>% count(Patient_id, Cell_subtype) %>% pivot_wider(names_from=Cell_subtype,values_from=n,values_fill=0) %>% filter(tS1>0,tS2>0) %>% pull(Patient_id)
d <- d %>% filter(Patient_id %in% keep_samples)
mat <- as.matrix(counts[,d$group_id]); rownames(mat) <- counts[[1]]
y <- DGEList(mat); y <- calcNormFactors(y)
X <- model.matrix(~Patient_id + Cell_subtype, data=d)
y <- estimateDisp(y,X,robust=TRUE); fit <- glmQLFit(y,X,robust=TRUE)
qlf <- glmQLFTest(fit,coef="Cell_subtypetS2")
write.csv(topTags(qlf,n=Inf)$table,file.path(root,"person4_final/results/edgeR_tS2_vs_tS1_all_genes.csv"),row.names=TRUE)
sessionInfo()
