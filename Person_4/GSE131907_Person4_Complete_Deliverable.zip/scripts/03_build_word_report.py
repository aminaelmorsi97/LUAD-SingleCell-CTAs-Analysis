#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[2]; BASE=ROOT/'person4_final'; RES=BASE/'results'; FIG=BASE/'figures'
rank=pd.read_csv(RES/'CTA_Ranking_Preliminary.csv'); site=pd.read_csv(RES/'CTA_Exploratory_Metastasis_vs_Primary.csv')
paired=pd.read_csv(RES/'CTA_Paired_tS2_vs_tS1.csv'); assoc=pd.read_csv(RES/'CTA_Sample_Score_Associations.csv')
sens=pd.read_csv(RES/'CNV889_Sensitivity_Summary.csv'); audit=pd.read_csv(RES/'Data_Audit.csv')

doc=Document(); sec=doc.sections[0]; sec.top_margin=Inches(.7); sec.bottom_margin=Inches(.7); sec.left_margin=Inches(.75); sec.right_margin=Inches(.75)
styles=doc.styles
styles['Normal'].font.name='Arial'; styles['Normal'].font.size=Pt(10.5)
for st in ['Title','Heading 1','Heading 2','Heading 3']:
    styles[st].font.name='Arial'; styles[st].font.color.rgb=RGBColor(0,0,0)
styles['Title'].font.size=Pt(22); styles['Heading 1'].font.size=Pt(16); styles['Heading 2'].font.size=Pt(13)

def rtl(p, align=WD_ALIGN_PARAGRAPH.RIGHT):
    p.alignment=align; p.paragraph_format.space_after=Pt(6); p.paragraph_format.line_spacing=1.15
    pPr=p._p.get_or_add_pPr(); bidi=OxmlElement('w:bidi'); bidi.set(qn('w:val'),'1'); pPr.append(bidi)
    return p
def para(text,bold=False):
    p=rtl(doc.add_paragraph()); r=p.add_run(text); r.bold=bold; r.font.name='Arial'; return p
def heading(text,level=1): return rtl(doc.add_heading(text,level=level))
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
def table(headers, rows, widths=None):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i]; c.text=str(h); shade(c,'1F4E78'); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for p in c.paragraphs: p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.runs[0].font.color.rgb=RGBColor(255,255,255); p.runs[0].bold=True; p.runs[0].font.size=Pt(9)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,v in enumerate(row):
            cells[i].text=str(v); cells[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if ri%2: shade(cells[i],'EAF2F8')
            for p in cells[i].paragraphs: p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.runs[0].font.size=Pt(8.5)
    doc.add_paragraph(); return t
def fig(name,caption):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run().add_picture(str(FIG/name),width=Inches(6.6))
    c=doc.add_paragraph(caption); c.alignment=WD_ALIGN_PARAGRAPH.CENTER; c.runs[0].italic=True; c.runs[0].font.size=Pt(9)

p=doc.add_paragraph(); p.style='Title'; rtl(p,WD_ALIGN_PARAGRAPH.CENTER); p.add_run('التقرير النهائي لمهمة الشخص الرابع')
p=rtl(doc.add_paragraph(),WD_ALIGN_PARAGRAPH.CENTER); p.add_run('تحليل مستضدات السرطان والخصية والإحصاء في GSE131907').bold=True
p=rtl(doc.add_paragraph(),WD_ALIGN_PARAGRAPH.CENTER); p.add_run('دراسة سرطان الرئة الغدي على مستوى الخلية المفردة')
doc.add_paragraph(); para('النتيجة الرئيسية: اكتملت تحليلات CTA على مستوى المريض. لم تتجاوز أي مقارنة حد FDR 0.05، لكن PRAME وXAGE1B وXAGE1A ظهرت كأفضل قائمة مرشحين استكشافية للتحقق المستقل ثم RT-qPCR في الدم.',True)

heading('1 نطاق المهمة والبيانات')
para('حلّلنا 31,136 خلية خبيثة من 32 مريضاً/عينة. شملت المواقع tLung وmLN وmBrain وtL/B. جرى إصلاح Patient ID في ملف الدرجات الكامل باستخدام خريطة Sample–Patient المعتمدة، ولم تبق أي قيمة مفقودة. استخدمت مجموعة 889 خلية المدعومة بـinferCNV كتحليل حساسية فقط، لأن اختيارها تم ضمن pilot ولا يمثل جميع الخلايا الخبيثة.')
table(['البند','القيمة','الحالة'],[[r['check'],r['observed'],'اجتاز' if r['pass'] else 'لم يجتز'] for _,r in audit.iterrows()])

heading('2 المنهجية الإحصائية')
para('اعتُبر المريض/العينة وحدة الاستدلال لتجنب pseudoreplication. قورنت tS2 مع tS1 باختبار Wilcoxon المقترن داخل المرضى المؤهلين بحد أدنى 20 خلية لكل حالة. قورنت النقائل mLN وmBrain مع tLung باختبارات Fisher للانتشار وMann–Whitney للتعبير، مع استبعاد tL/B بسبب طبيعتها المختلطة. اختبرت علاقات CTA مع درجات EMT وStemness وPlasticity وProliferation وLung differentiation باستخدام Spearman على 32 عينة، وصُححت الاختبارات بطريقة Benjamini–Hochberg.')
para('التحليل الأساسي CTA-specific ومكتمل. أُرفق سكربت edgeR لتأكيد pseudobulk على مستوى جميع الجينات عند تجهيز بيئة R المناسبة؛ لا تعتمد الاستنتاجات الحالية على تشغيله.')

heading('3 مقارنة النقائل مع الورم الأولي')
pr=site.set_index('gene').loc['PRAME']; xb=site.set_index('gene').loc['XAGE1B']; xa=site.set_index('gene').loc['XAGE1A']
para(f"ظهر PRAME في {int(pr.detected_metastasis)}/17 عينات نقيلية مقابل {int(pr.detected_primary)}/11 عينات أولية، بفارق انتشار {pr.prevalence_delta:.1%} وفارق وسيط log2CPM قدره {pr.median_log2CPM_delta:.2f}. إلا أن FDR كان {pr.mannwhitney_FDR_BH:.3f}، لذلك لا تُعد النتيجة إثباتاً نهائياً. بالنسبة لـXAGE1B وXAGE1A، كانت فروق الوسيط {xb.median_log2CPM_delta:.2f} و{xa.median_log2CPM_delta:.2f} على الترتيب، أيضاً دون دلالة بعد التصحيح.")
fig('Figure1_CTA_prevalence_difference.png','الشكل 1 فرق نسبة العينات التي اكتُشف فيها كل CTA بين النقائل والورم الأولي')
fig('Figure3_Top_CTA_site_expression.png','الشكل 2 تعبير أعلى المرشحين على مستوى عينات المرضى')

heading('4 الارتباط بالحالات الخلوية واللدونة')
para('لم تجتز أي علاقة بين CTA ودرجات الحالات الخلوية FDR 0.05. أبرز الاتجاهات غير المصححة كانت ارتباط PRAME وMAGEA12 وMAGEA6 سلباً بدرجة Lung differentiation، وارتباط XAGE1A إيجاباً بدرجة Proliferation. هذه اتجاهات مولدة للفرضيات فقط ويجب اختبارها في cohort مستقل.')
topa=assoc.sort_values('p_value').head(8)
table(['CTA','الدرجة','rho','P','FDR'],[[r.gene,r.score,f"{r.spearman_rho:.3f}",f"{r.p_value:.4f}",f"{r.FDR_BH_global:.3f}"] for _,r in topa.iterrows()])
fig('Figure2_CTA_state_association_heatmap.png','الشكل 3 ارتباطات Spearman على مستوى العينة بين CTA وبرامج الحالات الخلوية')

heading('5 مقارنة tS2 مع tS1 داخل الورم الأولي')
para('توفرت ثمانية أزواج مؤهلة. لم يختلف أي CTA بعد FDR. كان أقوى اتجاه لـXAGE1B بزيادة وسيطة 0.47 log2CPM في tS2 مقابل tS1، تلاه XAGE1A بزيادة 0.20؛ لكن FDR لكليهما 0.813. النتيجة الصحيحة هي عدم وجود دليل كافٍ على اختلاف الحالة في هذه العينة، لا إثبات غياب التأثير بيولوجياً.')
pt=paired.sort_values('wilcoxon_p').head(5)
table(['CTA','عدد الأزواج','فرق الوسيط','P','FDR'],[[r.gene,int(r.n_pairs),f"{r.median_paired_delta_tS2_minus_tS1:.3f}",f"{r.wilcoxon_p:.4f}",f"{r.FDR_BH:.3f}"] for _,r in pt.iterrows()])

heading('6 تحليل الحساسية باستخدام 889 خلية مدعومة بـinferCNV')
para('أُعيدت المقارنة باستخدام درجات حُسبت مرة واحدة في المجموعة الكاملة ثم اقتُطعت الخلايا الـ889، وذلك لتجنب اختلاف مرجع AddModuleScore بين مجموعتين. على مستوى 21 مريضاً مشتركاً، كانت الانزياحات الوسيطة صغيرة لجميع الدرجات. يدعم ذلك ثبات الاتجاه العام، لكنه لا يبرهن أن 889 خلية تمثل كل الورم.')
table(['الدرجة','المرضى','فرق الوسيط','الربع الأول','الربع الثالث'],[[r.score,int(r.n_patients),f"{r.median_delta:.4f}",f"{r.q1_delta:.4f}",f"{r.q3_delta:.4f}"] for _,r in sens.iterrows()])
fig('Figure4_CNV889_sensitivity.png','الشكل 4 فرق وسيط الدرجة لكل مريض بين مجموعة inferCNV المدعومة والمجموعة الكاملة')

heading('7 ترتيب المرشحين واختيار 2 إلى 3 CTAs')
para('جُمعت خمسة معايير استكشافية: فرق الانتشار النقائلي، فرق التعبير، انتشار الجين في النقائل، الارتباط ببرنامج تقدمي، وحجم اختلاف tS2–tS1. الأوزان معلنة في السكربت ولم تُستخدم قيمة P نفسها في بناء الدرجة. الترتيب أداة لاختيار مرشحين للتحقق، وليس نموذجاً تشخيصياً.')
table(['الترتيب','CTA','الدرجة المركبة','فرق الانتشار','فرق log2CPM'],[[int(r['rank']),r.gene,f"{r.composite_score:.3f}",f"{r.prevalence_delta:.1%}",f"{r.median_log2CPM_delta:.2f}"] for _,r in rank.head(6).iterrows()])
fig('Figure5_CTA_preliminary_ranking.png','الشكل 5 الترتيب الاستكشافي للـCTAs وفق المعايير المعلنة')
para('التوصية الحالية: حمل PRAME إلى التحقق الخارجي حتماً، وإضافة XAGE1B وXAGE1A كزوج XAGE متقارب بيولوجياً. قبل تصميم primers للدم، يجب التحقق من خصوصية التسلسل وعدم التفاعل المتصالب بين XAGE1A وXAGE1B، وقد يكون من الأنسب اختيار PRAME مع XAGE1B وجين ثالث مستقل بعد نتائج GSE123902 وGSE198291.')

heading('8 ما يمكن قوله وما لا يمكن قوله')
para('يمكن القول إن التحليل كشف اتجاهات متسقة تضع PRAME وXAGE1B وXAGE1A في مقدمة المرشحين، وإن نتائج inferCNV لا تغيّر درجات البرامج الخلوية جذرياً على مستوى المرضى المشتركين. لا يمكن الادعاء أن أي جين واسم نقائلي مثبت، أو أن حساسية ونوعية اختبار الدم مرتفعتان، لأن أياً من الاختبارات لم يجتز FDR ولأن قابلية الكشف في الدم لم تُختبر بعد.')

heading('9 الخطوات اللازمة قبل النشر')
for x in ['تطبيق التحليل نفسه بصورة مستقلة على GSE123902 وGSE198291 دون تغيير العتبات بعد رؤية النتائج.','تشغيل سكربت edgeR التأكيدي وتوثيق sessionInfo وإصدارات الحزم.','تثبيت قائمة CTA المرجعية ومراجع مجموعات EMT وPlasticity قبل النسخة النهائية.','عدم استخدام نتائج الشخص الثالث المبنية على 889 خلية كتحليل أساسي، بل كحساسية.','اختيار 2–3 جينات للـRT-qPCR بعد دمج قوة الإشارة، الانتشار، التحقق الخارجي، وقابلية تصميم primers نوعية.']:
    p=rtl(doc.add_paragraph(style='List Number')); p.add_run(x)

heading('10 الاستنتاج')
para('المهمة الرابعة مكتملة على بيانات GSE131907 ضمن الحدود المتاحة. النتائج مشجعة لتكوين قائمة مرشحين، لكنها سلبية إحصائياً بعد التصحيح. أفضل قرار علمي هو تقديمها كمرحلة discovery شفافة، ثم اعتبار نجاح التحقق المستقل شرطاً لترشيح الجينات إلى دراسة الدم السريرية.')

out=BASE/'GSE131907_Person4_Final_Report_AR.docx'; doc.save(out); print(out)
