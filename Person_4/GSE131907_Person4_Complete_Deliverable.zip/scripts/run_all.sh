#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python "$SCRIPT_DIR/01_person4_complete_analysis.py"
echo "Core patient-level analysis complete. Optional edgeR confirmation: Rscript $SCRIPT_DIR/02_edgeR_confirmatory.R"
