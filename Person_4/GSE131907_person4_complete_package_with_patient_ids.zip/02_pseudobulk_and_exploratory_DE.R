rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(edgeR)
})

obj <- readRDS("GSE131907_malignant_portable.rds")
counts <- LayerData(obj, assay = "RNA", layer = "counts")
md <- obj@meta.data
stopifnot(inherits(counts, "sparseMatrix"), identical(colnames(counts), rownames(md)))

mapping <- read.csv("GSE131907_sample_to_patient_mapping.csv", stringsAsFactors = FALSE)
stopifnot(identical(colnames(mapping), c("Sample", "Patient_id")))
stopifnot(!anyNA(mapping), !anyDuplicated(mapping$Sample))
md$Patient_id <- mapping$Patient_id[match(md$Sample, mapping$Sample)]
stopifnot(!anyNA(md$Patient_id))

aggregate_sparse <- function(counts, labels) {
  labels <- factor(labels)
  design <- sparse.model.matrix(~ 0 + labels)
  colnames(design) <- levels(labels)
  out <- counts %*% design
  rownames(out) <- rownames(counts)
  out
}

# Primary pseudobulk: one column per biological sample.
pb_sample <- aggregate_sparse(counts, md$Sample)
saveRDS(pb_sample, "GSE131907_pseudobulk_counts_by_sample.rds", compress = "xz")

# Sample × annotated tumor state pseudobulk.
group_id <- paste(md$Sample, md$Cell_subtype, sep = "__")
pb_state <- aggregate_sparse(counts, group_id)
saveRDS(pb_state, "GSE131907_pseudobulk_counts_by_sample_state.rds", compress = "xz")

group_design <- unique(data.frame(
  group_id = group_id,
  Sample = md$Sample,
  Patient_id = md$Patient_id,
  Sample_Origin = md$Sample_Origin,
  Cell_subtype = md$Cell_subtype,
  stringsAsFactors = FALSE
))
group_design$n_cells <- as.integer(table(group_id)[group_design$group_id])
group_design <- group_design[match(colnames(pb_state), group_design$group_id), ]
stopifnot(identical(group_design$group_id, colnames(pb_state)))

# Exploratory paired tS2-versus-tS1 comparison within primary-tumor samples.
# This is not the final malignant-cell result: the states were assigned by the
# original study and must later be checked against the inferCNV sensitivity set.
eligible <- subset(group_design, Cell_subtype %in% c("tS1", "tS2") & n_cells >= 20)
paired_samples <- intersect(
  eligible$Sample[eligible$Cell_subtype == "tS1"],
  eligible$Sample[eligible$Cell_subtype == "tS2"]
)
de_meta <- subset(eligible, Sample %in% paired_samples)
de_meta <- de_meta[match(colnames(pb_state), de_meta$group_id, nomatch = 0L), ]
de_counts <- pb_state[, de_meta$group_id, drop = FALSE]

stopifnot(length(paired_samples) >= 3L)
stopifnot(!anyDuplicated(unique(de_meta[c("Sample", "Patient_id")])$Patient_id))
de_meta$Patient_id <- factor(de_meta$Patient_id)
de_meta$Cell_subtype <- relevel(factor(de_meta$Cell_subtype), ref = "tS1")
design <- model.matrix(~ Patient_id + Cell_subtype, data = de_meta)

y <- DGEList(counts = de_counts, samples = de_meta)
keep <- filterByExpr(y, design = design)
y <- y[keep, , keep.lib.sizes = FALSE]
y <- calcNormFactors(y, method = "TMM")
y <- estimateDisp(y, design, robust = TRUE)
fit <- glmQLFit(y, design, robust = TRUE)
coef_name <- "Cell_subtypetS2"
qlf <- glmQLFTest(fit, coef = match(coef_name, colnames(design)))
de_all <- topTags(qlf, n = Inf, sort.by = "PValue")$table
de_all$gene <- rownames(de_all)
de_all <- de_all[, c("gene", setdiff(colnames(de_all), "gene"))]
write.csv(de_all, "GSE131907_exploratory_tS2_vs_tS1_edgeR.csv", row.names = FALSE)

cta <- c("MAGEA1","MAGEA3","MAGEA4","MAGEA6","MAGEA10","MAGEA12",
         "CTAG1B","CTAG2","PRAME","XAGE1A","XAGE1B","GAGE2A","SSX1")
write.csv(de_all[de_all$gene %in% cta, ],
          "GSE131907_exploratory_tS2_vs_tS1_CTA_edgeR.csv", row.names = FALSE)

# Do not fit a final Sample_Origin model until inferCNV sensitivity membership
# is available. Patient_id is now mapped completely, but Sample_Origin and
# Cell_subtype remain structurally confounded in this object.
cat("Paired samples used:", paste(paired_samples, collapse = ", "), "\n")
cat("Paired patients used:", paste(levels(de_meta$Patient_id), collapse = ", "), "\n")
cat("Genes retained by filterByExpr:", sum(keep), "\n")
sessionInfo()
