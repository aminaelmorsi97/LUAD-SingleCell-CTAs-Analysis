rm(list = ls())
gc()

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

rds_file <- "GSE131907_malignant_portable.rds"
obj <- readRDS(rds_file)

cat("class:", class(obj), "\n")
cat("dimensions:", paste(dim(obj), collapse = " x "), "\n")
cat("assays:", paste(Assays(obj), collapse = ", "), "\n")
cat("default assay:", DefaultAssay(obj), "\n")
cat("RNA layers:", paste(Layers(obj[["RNA"]]), collapse = ", "), "\n")

counts <- tryCatch(
  LayerData(obj, assay = "RNA", layer = "counts"),
  error = function(e) GetAssayData(obj, assay = "RNA", slot = "counts")
)

stopifnot(inherits(counts, "sparseMatrix"))
stopifnot(identical(dim(counts), c(27578L, 31136L)))
stopifnot(anyDuplicated(rownames(obj)) == 0L)
stopifnot(anyDuplicated(colnames(obj)) == 0L)
stopifnot(sum(is.na(rownames(obj))) == 0L)
stopifnot(sum(is.na(colnames(obj))) == 0L)
stopifnot(identical(colnames(obj), rownames(obj@meta.data)))
stopifnot(all(Matrix::colSums(counts) == obj$nCount_RNA))

mapping <- read.csv("GSE131907_sample_to_patient_mapping.csv", stringsAsFactors = FALSE)
stopifnot(identical(colnames(mapping), c("Sample", "Patient_id")))
stopifnot(!anyNA(mapping), !anyDuplicated(mapping$Sample))
obj$Patient_id <- mapping$Patient_id[match(obj$Sample, mapping$Sample)]
stopifnot(!anyNA(obj$Patient_id))

cat("counts class:", class(counts), "\n")
cat("counts dimensions:", paste(dim(counts), collapse = " x "), "\n")
cat("sparse counts:", inherits(counts, "sparseMatrix"), "\n")
cat("metadata columns:\n")
print(colnames(obj@meta.data))
cat("Cell_subtype table:\n")
print(table(obj$Cell_subtype, useNA = "ifany"))
cat("Sample_Origin table:\n")
print(table(obj$Sample_Origin, useNA = "ifany"))
cat("Patient mapping audit:\n")
print(c(
  mapping_rows = nrow(mapping),
  mapping_unique_patients = length(unique(mapping$Patient_id)),
  analyzed_samples = length(unique(obj$Sample)),
  analyzed_patients = length(unique(obj$Patient_id))
))

candidate_columns <- grep(
  "patient|sample|tissue|metast|site|histology",
  colnames(obj@meta.data), value = TRUE, ignore.case = TRUE
)
cat("candidate design columns:\n")
print(candidate_columns)

cta_initial <- c(
  "MAGEA1", "MAGEA2", "MAGEA3", "MAGEA4", "MAGEA6", "MAGEA10", "MAGEA12",
  "CTAG1A", "CTAG1B", "CTAG2", "PRAME", "XAGE1A", "XAGE1B", "GAGE1",
  "GAGE2A", "GAGE2C", "SSX1", "SSX2", "SSX4", "AKAP4"
)
cat("CTA present:\n")
print(intersect(cta_initial, rownames(obj)))
cat("CTA missing:\n")
print(setdiff(cta_initial, rownames(obj)))

sessionInfo()
